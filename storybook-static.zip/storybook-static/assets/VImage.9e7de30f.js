import{j as e}from"./jsx-runtime.d19f6329.js";import{M as p,C as r,b as x}from"./index.6b7544c1.js";import{V as i,D as c,I as a}from"./VImage.stories.3ead21f1.js";import{u as n}from"./index.912ed65d.js";import"./iframe.9b02d578.js";import"../sb-preview/runtime.js";import"./_commonjsHelpers.712cc82f.js";import"./index.d0b9ec93.js";import"./index.6eeffd5a.js";import"./index.7e22da21.js";import"./index.76fcd3ae.js";function t(s){const o=Object.assign({h1:"h1",p:"p",pre:"pre",code:"code",h2:"h2",blockquote:"blockquote"},n(),s.components);return e.exports.jsxs(e.exports.Fragment,{children:[e.exports.jsx(p,{of:i}),`
`,e.exports.jsx(o.h1,{id:"v-image",children:"v-image"}),`
`,e.exports.jsx(o.p,{children:"\u56FE\u7247\u56FE\u5C42\u7EC4\u4EF6\uFF0C\u652F\u6301\u9759\u6001\u56FE\u7247\u3001WMS\u3001GeoImage \u7B49\u591A\u79CD\u56FE\u7247\u6E90\u3002"}),`
`,e.exports.jsx(o.pre,{children:e.exports.jsx(o.code,{className:"language-js",children:`import { VMap, VTile, VImage } from "v-ol-map";
`})}),`
`,e.exports.jsx(o.h2,{id:"\u57FA\u7840\u793A\u4F8B",children:"\u57FA\u7840\u793A\u4F8B"}),`
`,e.exports.jsxs(o.blockquote,{children:[`
`,e.exports.jsx(o.p,{children:"\u5728\u6307\u5B9A\u5730\u7406\u8303\u56F4\u5185\u663E\u793A\u9759\u6001\u56FE\u7247"}),`
`]}),`
`,e.exports.jsx(r,{of:c}),`
`,e.exports.jsx(o.h2,{id:"wms-\u793A\u4F8B",children:"WMS \u793A\u4F8B"}),`
`,e.exports.jsxs(o.blockquote,{children:[`
`,e.exports.jsxs(o.p,{children:["\u57FA\u4E8E ",e.exports.jsx(o.code,{children:"ol/source/ImageWMS"})," \u7684 WMS \u56FE\u5C42\u793A\u4F8B"]}),`
`]}),`
`,e.exports.jsx(r,{of:a}),`
`,e.exports.jsx(o.h2,{id:"docs",children:"Docs"}),`
`,e.exports.jsx(x,{})]})}function D(s={}){const{wrapper:o}=Object.assign({},n(),s.components);return o?e.exports.jsx(o,Object.assign({},s,{children:e.exports.jsx(t,s)})):t(s)}export{D as default};
