import{n as m,V as M,a as v,i as l}from"./index.76fcd3ae.js";var g=function(){var e=this,t=e.$createElement,n=e._self._c||t;return n("div",{staticClass:"measure-example"},[n("v-map",{staticStyle:{width:"100%",height:"600px"},attrs:{view:e.view}},[n("v-tile",{attrs:{"tile-type":"TD"}}),e.isMeasuring?n("v-measure",{attrs:{type:e.measureType},on:{bindbindBindBindBindBindMeasureEnd:e.onMeasureEnd}}):e._e()],1),n("div",{staticClass:"toolbar"},[n("button",{class:{active:e.measureType==="LineString"&&e.isMeasuring},on:{click:function(d){return e.startMeasure("LineString")}}},[e._v("\u6D4B\u8DDD")]),n("button",{class:{active:e.measureType==="Polygon"&&e.isMeasuring},on:{click:function(d){return e.startMeasure("Polygon")}}},[e._v("\u6D4B\u9762")]),n("button",{on:{click:e.stopMeasure}},[e._v("\u505C\u6B62")])]),e.measureResult?n("div",{staticClass:"result"},[e._v(e._s(e.measureResult))]):e._e()],1)},_=[];const x={name:"MeasureExample",components:{VMap:M,VTile:v,VMeasure:l},data(){return{view:{center:[118.0894,24.4798],zoom:13,projection:"EPSG:4326"},isMeasuring:!1,measureType:"LineString",measureResult:""}},methods:{startMeasure(e){this.measureType=e,this.isMeasuring=!0},stopMeasure(){this.isMeasuring=!1},onMeasureEnd(e){this.measureResult=e}}},r={};var c=m(x,g,_,!1,b,"32a40d40",null,null);function b(e){for(let t in r)this[t]=r[t]}const y=function(){return c.exports}();c.exports.__docgenInfo={displayName:"MeasureExample",exportName:"default",description:"",tags:{},sourceFiles:["/Users/feipan/Desktop/\u9879\u76EE/\u6D4B\u8BD5/vue-openlayers-map-vite/src/stories/Measure/MeasureExample.vue"]};const f=`<template>
  <div class="measure-example">
    <v-map :view="view" style="width: 100%; height: 600px">
      <v-tile tile-type="TD" />
      <v-measure v-if="isMeasuring" :type="measureType" @bindbindBindBindBindBindMeasureEnd="onMeasureEnd" />
    </v-map>
    <div class="toolbar">
      <button :class="{ active: measureType === 'LineString' && isMeasuring }" @click="startMeasure('LineString')">\u6D4B\u8DDD</button>
      <button :class="{ active: measureType === 'Polygon' && isMeasuring }" @click="startMeasure('Polygon')">\u6D4B\u9762</button>
      <button @click="stopMeasure">\u505C\u6B62</button>
    </div>
    <div class="result" v-if="measureResult">{{ measureResult }}</div>
  </div>
</template>

<script>
import { VMap, VTile, VMeasure } from "@/packages";

export default {
  name: "MeasureExample",
  components: { VMap, VTile, VMeasure },
  data() {
    return {
      view: { center: [118.0894, 24.4798], zoom: 13, projection: "EPSG:4326" },
      isMeasuring: false,
      measureType: "LineString",
      measureResult: "",
    };
  },
  methods: {
    startMeasure(type) {
      this.measureType = type;
      this.isMeasuring = true;
    },
    stopMeasure() {
      this.isMeasuring = false;
    },
    onMeasureEnd(result) {
      this.measureResult = result;
    },
  },
};
<\/script>

<style scoped>
.measure-example {
  position: relative;
}
.toolbar {
  position: absolute;
  top: 10px;
  left: 10px;
  background: white;
  padding: 10px;
  border-radius: 4px;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.15);
}
.toolbar button {
  margin-right: 5px;
  padding: 6px 12px;
  border: 1px solid #ddd;
  border-radius: 4px;
  cursor: pointer;
}
.toolbar button.active {
  background: #1890ff;
  color: white;
  border-color: #1890ff;
}
.result {
  position: absolute;
  bottom: 10px;
  left: 10px;
  background: white;
  padding: 10px;
  border-radius: 4px;
}
</style>
`,h={id:"3-2",title:"\u5DE5\u5177/Measure\u6D4B\u91CF\u5DE5\u5177",component:l,parameters:{docs:{description:{component:""}}}},s={parameters:{docs:{description:{story:"\u6D4B\u91CF\u5DE5\u5177\u793A\u4F8B\u3002\u652F\u6301\u8DDD\u79BB\u6D4B\u91CF\u548C\u9762\u79EF\u6D4B\u91CF"},source:{language:"html",code:f}}},render:()=>({components:{MeasureExample:y},template:"<MeasureExample />"})};var a,u,i,o,p;s.parameters={...s.parameters,docs:{...(a=s.parameters)==null?void 0:a.docs,source:{originalSource:`{
  parameters: {
    docs: {
      description: {
        story: "\u6D4B\u91CF\u5DE5\u5177\u793A\u4F8B\u3002\u652F\u6301\u8DDD\u79BB\u6D4B\u91CF\u548C\u9762\u79EF\u6D4B\u91CF"
      },
      source: {
        language: "html",
        code: MeasureExampleRaw
      }
    }
  },
  render: () => ({
    components: {
      MeasureExample
    },
    template: "<MeasureExample />"
  })
}`,...(i=(u=s.parameters)==null?void 0:u.docs)==null?void 0:i.source},description:{story:"\u6D4B\u91CF\u5DE5\u5177\u793A\u4F8B",...(p=(o=s.parameters)==null?void 0:o.docs)==null?void 0:p.description}}};const E=["Default"],T=Object.freeze(Object.defineProperty({__proto__:null,default:h,Default:s,__namedExportsOrder:E},Symbol.toStringTag,{value:"Module"}));export{s as D,T as V};
