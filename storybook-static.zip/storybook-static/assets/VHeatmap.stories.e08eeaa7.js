import{n as l,V as d,a as h,g as u}from"./index.76fcd3ae.js";var v=function(){var e=this,t=e.$createElement,a=e._self._c||t;return a("div",{staticClass:"heatmap-example"},[a("v-map",{staticStyle:{width:"100%",height:"600px"},attrs:{view:e.view}},[a("v-tile",{attrs:{"tile-type":"TD"}}),a("v-heatmap",{attrs:{features:e.features,blur:15,radius:10}})],1)],1)},_=[];const f={name:"HeatmapExample",components:{VMap:d,VTile:h,VHeatmap:u},data(){return{view:{center:[118.0894,24.4798],zoom:12,projection:"EPSG:4326"},features:this.generatePoints(200)}},methods:{generatePoints(e){const t=[];for(let a=0;a<e;a++)t.push({type:"point",coordinates:[118.0894+(Math.random()-.5)*.2,24.4798+(Math.random()-.5)*.2],weight:Math.random()});return t}}},r={};var c=l(f,v,_,!1,E,null,null,null);function E(e){for(let t in r)this[t]=r[t]}const x=function(){return c.exports}();c.exports.__docgenInfo={displayName:"HeatmapExample",exportName:"default",description:"",tags:{},sourceFiles:["/Users/feipan/Desktop/\u9879\u76EE/\u6D4B\u8BD5/vue-openlayers-map-vite/src/stories/Heatmap/HeatmapExample.vue"]};const g=`<template>
  <div class="heatmap-example">
    <v-map :view="view" style="width: 100%; height: 600px">
      <v-tile tile-type="TD" />
      <v-heatmap :features="features" :blur="15" :radius="10" />
    </v-map>
  </div>
</template>

<script>
import { VMap, VTile, VHeatmap } from "@/packages";

export default {
  name: "HeatmapExample",
  components: { VMap, VTile, VHeatmap },
  data() {
    return {
      view: { center: [118.0894, 24.4798], zoom: 12, projection: "EPSG:4326" },
      features: this.generatePoints(200),
    };
  },
  methods: {
    generatePoints(count) {
      const points = [];
      for (let i = 0; i < count; i++) {
        points.push({
          type: "point",
          coordinates: [118.0894 + (Math.random() - 0.5) * 0.2, 24.4798 + (Math.random() - 0.5) * 0.2],
          weight: Math.random(),
        });
      }
      return points;
    },
  },
};
<\/script>
`,H={id:"2-5",title:"\u56FE\u5C42/Heatmap\u70ED\u529B\u56FE",component:u,parameters:{docs:{description:{component:""}}}},n={parameters:{docs:{description:{story:"\u70ED\u529B\u56FE\u793A\u4F8B\u3002\u6839\u636E\u70B9\u4F4D\u6743\u91CD\u663E\u793A\u70ED\u529B\u5206\u5E03"},source:{language:"html",code:g}}},render:()=>({components:{HeatmapExample:x},template:"<HeatmapExample />"})};var o,s,p,i,m;n.parameters={...n.parameters,docs:{...(o=n.parameters)==null?void 0:o.docs,source:{originalSource:`{
  parameters: {
    docs: {
      description: {
        story: "\u70ED\u529B\u56FE\u793A\u4F8B\u3002\u6839\u636E\u70B9\u4F4D\u6743\u91CD\u663E\u793A\u70ED\u529B\u5206\u5E03"
      },
      source: {
        language: "html",
        code: HeatmapExampleRaw
      }
    }
  },
  render: () => ({
    components: {
      HeatmapExample
    },
    template: "<HeatmapExample />"
  })
}`,...(p=(s=n.parameters)==null?void 0:s.docs)==null?void 0:p.source},description:{story:"\u70ED\u529B\u56FE\u793A\u4F8B",...(m=(i=n.parameters)==null?void 0:i.docs)==null?void 0:m.description}}};const y=["Default"],w=Object.freeze(Object.defineProperty({__proto__:null,default:H,Default:n,__namedExportsOrder:y},Symbol.toStringTag,{value:"Module"}));export{n as D,w as V};
