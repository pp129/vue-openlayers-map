import{n as m,V as y,a as _,c as x,j as f}from"./index.76fcd3ae.js";var g=function(){var e=this,t=e.$createElement,n=e._self._c||t;return n("div",{staticClass:"overlay-example"},[n("v-map",{ref:"map",staticStyle:{width:"100%",height:"600px"},attrs:{view:e.view}},[n("v-tile",{attrs:{"tile-type":"TD"}}),n("v-vector",{attrs:{features:e.features},on:{singleclick:e.onClickFeature}}),n("v-overlay",{ref:"popup",attrs:{position:e.popupPosition,positioning:"bottom-center",offset:[0,-10],"auto-pan":!0,"class-name":"custom-popup"}},[e.selectedFeature?n("div",{staticClass:"popup-content"},[n("div",{staticClass:"popup-header"},[n("span",[e._v(e._s(e.selectedFeature.name))]),n("button",{staticClass:"close-btn",on:{click:e.closePopup}},[e._v("\xD7")])]),n("div",{staticClass:"popup-body"},[n("p",[e._v("\u5750\u6807: "+e._s(e.formatCoords(e.selectedFeature.coordinates)))]),n("p",[e._v("\u7B49\u7EA7: "+e._s(e.selectedFeature.level))])])]):e._e()])],1),n("div",{staticClass:"tip"},[e._v("\u70B9\u51FB\u5730\u56FE\u4E0A\u7684\u70B9\u6807\u8BB0\u67E5\u770B\u5F39\u7A97")])],1)},h=[];const F={name:"OverlayExample",components:{VMap:y,VTile:_,VVector:x,VOverlay:f},data(){return{view:{center:[118.0894,24.4798],zoom:13,projection:"EPSG:4326"},map:null,features:[{id:"point1",coordinates:[118.08,24.47],style:{circle:{radius:10,fill:{color:"#1890ff"},stroke:{color:"#fff",width:2}}},properties:{name:"\u70B9\u4F4D A",level:1}},{id:"point2",coordinates:[118.1,24.49],style:{circle:{radius:10,fill:{color:"#52c41a"},stroke:{color:"#fff",width:2}}},properties:{name:"\u70B9\u4F4D B",level:2}},{id:"point3",coordinates:[118.09,24.46],style:{circle:{radius:10,fill:{color:"#f5222d"},stroke:{color:"#fff",width:2}}},properties:{name:"\u70B9\u4F4D C",level:3}}],popupPosition:void 0,selectedFeature:null}},methods:{onClickFeature(e,t){var n,r,s;if(t){const a=t.get("coordinates")||((n=t.getGeometry())==null?void 0:n.getCoordinates());this.selectedFeature={name:t.get("name")||((r=t.get("properties"))==null?void 0:r.name)||"\u672A\u77E5",coordinates:a,level:t.get("level")||((s=t.get("properties"))==null?void 0:s.level)||"-"},this.popupPosition=a}else this.closePopup()},closePopup(){this.popupPosition=void 0,this.selectedFeature=null},formatCoords(e){return e?`${e[0].toFixed(4)}, ${e[1].toFixed(4)}`:"-"}}},p={};var v=m(F,g,h,!1,b,"ea62eafc",null,null);function b(e){for(let t in p)this[t]=p[t]}const E=function(){return v.exports}();v.exports.__docgenInfo={displayName:"OverlayExample",exportName:"default",description:"",tags:{},sourceFiles:["/Users/feipan/Desktop/\u9879\u76EE/\u6D4B\u8BD5/vue-openlayers-map-vite/src/stories/Overlay/OverlayExample.vue"]};const C=`<template>
  <div class="overlay-example">
    <v-map ref="map" :view="view" style="width: 100%; height: 600px">
      <v-tile tile-type="TD" />
      <v-vector :features="features" @singleclick="onClickFeature" />
      <v-overlay
        ref="popup"
        :position="popupPosition"
        :positioning="'bottom-center'"
        :offset="[0, -10]"
        :auto-pan="true"
        class-name="custom-popup"
      >
        <div v-if="selectedFeature" class="popup-content">
          <div class="popup-header">
            <span>{{ selectedFeature.name }}</span>
            <button class="close-btn" @click="closePopup">\xD7</button>
          </div>
          <div class="popup-body">
            <p>\u5750\u6807: {{ formatCoords(selectedFeature.coordinates) }}</p>
            <p>\u7B49\u7EA7: {{ selectedFeature.level }}</p>
          </div>
        </div>
      </v-overlay>
    </v-map>
    <div class="tip">\u70B9\u51FB\u5730\u56FE\u4E0A\u7684\u70B9\u6807\u8BB0\u67E5\u770B\u5F39\u7A97</div>
  </div>
</template>

<script>
import { VMap, VTile, VVector, VOverlay } from "v-ol-map";

export default {
  name: "OverlayExample",
  components: { VMap, VTile, VVector, VOverlay },
  data() {
    return {
      view: {
        center: [118.0894, 24.4798],
        zoom: 13,
        projection: "EPSG:4326",
      },
      map: null,
      features: [
        {
          id: "point1",
          coordinates: [118.08, 24.47],
          style: {
            circle: {
              radius: 10,
              fill: { color: "#1890ff" },
              stroke: { color: "#fff", width: 2 },
            },
          },
          properties: { name: "\u70B9\u4F4D A", level: 1 },
        },
        {
          id: "point2",
          coordinates: [118.1, 24.49],
          style: {
            circle: {
              radius: 10,
              fill: { color: "#52c41a" },
              stroke: { color: "#fff", width: 2 },
            },
          },
          properties: { name: "\u70B9\u4F4D B", level: 2 },
        },
        {
          id: "point3",
          coordinates: [118.09, 24.46],
          style: {
            circle: {
              radius: 10,
              fill: { color: "#f5222d" },
              stroke: { color: "#fff", width: 2 },
            },
          },
          properties: { name: "\u70B9\u4F4D C", level: 3 },
        },
      ],
      popupPosition: undefined,
      selectedFeature: null,
    };
  },
  methods: {
    onClickFeature(evt, feature) {
      if (feature) {
        const coordinates = feature.get("coordinates") || feature.getGeometry()?.getCoordinates();
        this.selectedFeature = {
          name: feature.get("name") || feature.get("properties")?.name || "\u672A\u77E5",
          coordinates: coordinates,
          level: feature.get("level") || feature.get("properties")?.level || "-",
        };
        this.popupPosition = coordinates;
      } else {
        this.closePopup();
      }
    },
    closePopup() {
      this.popupPosition = undefined;
      this.selectedFeature = null;
    },
    formatCoords(coords) {
      if (!coords) return "-";
      return \`\${coords[0].toFixed(4)}, \${coords[1].toFixed(4)}\`;
    },
  },
};
<\/script>

<style scoped>
.overlay-example {
  position: relative;
}
.tip {
  position: absolute;
  top: 10px;
  left: 50%;
  transform: translateX(-50%);
  background: rgba(0, 0, 0, 0.7);
  color: #fff;
  padding: 8px 16px;
  border-radius: 4px;
  font-size: 14px;
}
</style>

<style>
/* Popup \u6837\u5F0F\u9700\u8981\u5168\u5C40 */
.custom-popup {
  background: transparent;
}
.popup-content {
  background: #fff;
  border-radius: 8px;
  box-shadow: 0 4px 16px rgba(0, 0, 0, 0.15);
  min-width: 200px;
  overflow: hidden;
}
.popup-content::after {
  content: "";
  position: absolute;
  bottom: -8px;
  left: 50%;
  transform: translateX(-50%);
  border: 8px solid transparent;
  border-top-color: #fff;
  border-bottom: 0;
}
.popup-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 10px 15px;
  background: #1890ff;
  color: #fff;
  font-weight: bold;
}
.close-btn {
  background: transparent;
  border: none;
  color: #fff;
  font-size: 20px;
  cursor: pointer;
  line-height: 1;
}
.popup-body {
  padding: 15px;
}
.popup-body p {
  margin: 5px 0;
  font-size: 14px;
  color: #333;
}
</style>
`,O={id:"9-1",title:"\u5176\u4ED6/Overlay\u5F39\u6846",component:f,parameters:{docs:{description:{component:""}}}},o={parameters:{docs:{description:{story:"\u70B9\u51FB\u5730\u56FE\u4E0A\u7684\u70B9\u6807\u8BB0\u67E5\u770B\u4FE1\u606F\u5F39\u7A97\uFF0C\u5C55\u793A\u4E86\u8986\u76D6\u7269\u7684\u5178\u578B\u7528\u6CD5\u3002"},source:{language:"html",code:C}}},render:()=>({components:{OverlayExample:E},template:"<OverlayExample />"})};var i,l,c,u,d;o.parameters={...o.parameters,docs:{...(i=o.parameters)==null?void 0:i.docs,source:{originalSource:`{
  parameters: {
    docs: {
      description: {
        story: "\u70B9\u51FB\u5730\u56FE\u4E0A\u7684\u70B9\u6807\u8BB0\u67E5\u770B\u4FE1\u606F\u5F39\u7A97\uFF0C\u5C55\u793A\u4E86\u8986\u76D6\u7269\u7684\u5178\u578B\u7528\u6CD5\u3002"
      },
      source: {
        language: "html",
        code: OverlayExampleRaw
      }
    }
  },
  render: () => ({
    components: {
      OverlayExample
    },
    template: "<OverlayExample />"
  })
}`,...(c=(l=o.parameters)==null?void 0:l.docs)==null?void 0:c.source},description:{story:`Popup \u5F39\u7A97\u793A\u4F8B
\u70B9\u51FB\u5730\u56FE\u8981\u7D20\u663E\u793A\u4FE1\u606F\u5F39\u7A97`,...(d=(u=o.parameters)==null?void 0:u.docs)==null?void 0:d.description}}};const P=["Popup"],k=Object.freeze(Object.defineProperty({__proto__:null,default:O,Popup:o,__namedExportsOrder:P},Symbol.toStringTag,{value:"Module"}));export{o as P,k as V};
