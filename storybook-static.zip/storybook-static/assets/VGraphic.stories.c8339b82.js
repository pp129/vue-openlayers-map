import{n as m,V as d,a as f,e as u}from"./index.76fcd3ae.js";var h=function(){var t=this,n=t.$createElement,e=t._self._c||n;return e("div",{staticClass:"graphic-example"},[e("v-map",{staticStyle:{width:"100%",height:"600px"},attrs:{view:t.view}},[e("v-tile",{attrs:{"tile-type":"TD"}}),e("v-graphic",{attrs:{features:t.features,"feature-style":t.featureStyle}})],1)],1)},v=[];const _={name:"GraphicExample",components:{VMap:d,VTile:f,VGraphic:u},data(){return{view:{center:[118.0894,24.4798],zoom:12,projection:"EPSG:4326"},features:this.generatePoints(100),featureStyle:{circle:{radius:6,fill:{color:"#3399CC"},stroke:{color:"#ffffff",width:2}}}}},methods:{generatePoints(t){const n=[];for(let e=0;e<t;e++)n.push({id:`point-${e}`,coordinates:[118.0894+(Math.random()-.5)*.3,24.4798+(Math.random()-.5)*.3],name:`Point ${e+1}`});return n}}},r={};var l=m(_,h,v,!1,x,null,null,null);function x(t){for(let n in r)this[n]=r[n]}const g=function(){return l.exports}();l.exports.__docgenInfo={displayName:"GraphicExample",exportName:"default",description:"",tags:{},sourceFiles:["/Users/feipan/Desktop/\u9879\u76EE/\u6D4B\u8BD5/vue-openlayers-map-vite/src/stories/Graphic/GraphicExample.vue"]};const G=`<template>
  <div class="graphic-example">
    <v-map :view="view" style="width: 100%; height: 600px">
      <v-tile tile-type="TD" />
      <v-graphic :features="features" :feature-style="featureStyle" />
    </v-map>
  </div>
</template>

<script>
import { VMap, VTile, VGraphic } from "@/packages";

export default {
  name: "GraphicExample",
  components: { VMap, VTile, VGraphic },
  data() {
    return {
      view: { center: [118.0894, 24.4798], zoom: 12, projection: "EPSG:4326" },
      features: this.generatePoints(100),
      featureStyle: {
        circle: {
          radius: 6,
          fill: { color: "#3399CC" },
          stroke: { color: "#ffffff", width: 2 },
        },
      },
    };
  },
  methods: {
    generatePoints(count) {
      const features = [];
      for (let i = 0; i < count; i++) {
        features.push({
          id: \`point-\${i}\`,
          coordinates: [118.0894 + (Math.random() - 0.5) * 0.3, 24.4798 + (Math.random() - 0.5) * 0.3],
          name: \`Point \${i + 1}\`,
        });
      }
      return features;
    },
  },
};
<\/script>
`,E={id:"2-7",title:"\u56FE\u5C42/Graphic\u56FE\u5F62\u56FE\u5C42",component:u,parameters:{docs:{description:{component:""}}}},a={parameters:{docs:{description:{story:"Canvas \u56FE\u5F62\u56FE\u5C42\u793A\u4F8B\u3002\u4F7F\u7528 Canvas \u9AD8\u6548\u6E32\u67D3\u5927\u91CF\u70B9\u4F4D"},source:{language:"html",code:G}}},render:()=>({components:{GraphicExample:g},template:"<GraphicExample />"})};var o,s,i,c,p;a.parameters={...a.parameters,docs:{...(o=a.parameters)==null?void 0:o.docs,source:{originalSource:`{
  parameters: {
    docs: {
      description: {
        story: "Canvas \u56FE\u5F62\u56FE\u5C42\u793A\u4F8B\u3002\u4F7F\u7528 Canvas \u9AD8\u6548\u6E32\u67D3\u5927\u91CF\u70B9\u4F4D"
      },
      source: {
        language: "html",
        code: GraphicExampleRaw
      }
    }
  },
  render: () => ({
    components: {
      GraphicExample
    },
    template: "<GraphicExample />"
  })
}`,...(i=(s=a.parameters)==null?void 0:s.docs)==null?void 0:i.source},description:{story:"Canvas \u56FE\u5F62\u56FE\u5C42\u793A\u4F8B",...(p=(c=a.parameters)==null?void 0:c.docs)==null?void 0:p.description}}};const y=["Default"],F=Object.freeze(Object.defineProperty({__proto__:null,default:E,Default:a,__namedExportsOrder:y},Symbol.toStringTag,{value:"Module"}));export{a as D,F as V};
