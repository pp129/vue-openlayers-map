import{n as w,V as c,a as B,c as i}from"./index.76fcd3ae.js";import{D as T}from"./VMap.stories.ccd9cff5.js";var Y=function(){var e=this,t=e.$createElement,o=e._self._c||t;return o("v-map",{staticStyle:{width:"100%",height:"600px"},attrs:{view:e.view}},[o("v-tile",{attrs:{"tile-type":"TD"}}),o("v-vector",{attrs:{geoJson:e.geoJsonData,layerStyle:e.layerStyle}})],1)},R=[];const P={name:"GeoJsonBasicExample",components:{VMap:c,VTile:B,VVector:i},data(){return{view:{center:[118.0894,24.4798],zoom:9,projection:"EPSG:4326"},geoJsonData:{type:"FeatureCollection",features:[{type:"Feature",properties:{id:"point-1",name:"\u53A6\u95E8\u5E02",style:{circle:{radius:10,fill:{color:"rgba(255, 0, 0, 0.8)"},stroke:{color:"#fff",width:2}},text:{text:"\u53A6\u95E8\u5E02",fill:{color:"#333"},offsetY:-20},styleFunction:function(e,t,o,l){const r=o.getView().getZoom(),a=l.getText(),p=e.get("style");let d="";return p&&(d=p.text.text),r&&a&&(r<=12&&a.setText(""),r>=13&&a.setText(d),r>=14&&a.setText(`\u6839\u636E\u5C42\u7EA7\u663E\u793A\u4E0D\u540C\u5185\u5BB9,\u5F53\u524D\u5C42\u7EA7\uFF1A${r}\u7EA7`),l.setText(a)),l}}},geometry:{type:"Point",coordinates:[118.0894,24.4798]}},{type:"Feature",properties:{id:"point-2",name:"\u6F33\u5DDE\u5E02"},geometry:{type:"Point",coordinates:[117.6469,24.5128]}},{type:"Feature",properties:{id:"point-3",name:"\u6CC9\u5DDE\u5E02",style:{circle:{radius:8,fill:{color:"rgba(0, 150, 0, 0.8)"},stroke:{color:"#fff",width:2}}}},geometry:{type:"Point",coordinates:[118.5894,24.9087]}}]},layerStyle:{circle:{radius:8,fill:{color:"rgba(33, 150, 243, 0.8)"},stroke:{color:"#fff",width:2}}}}}},u={};var G=w(P,Y,R,!1,C,null,null,null);function C(e){for(let t in u)this[t]=u[t]}const S=function(){return G.exports}();G.exports.__docgenInfo={displayName:"GeoJsonBasicExample",exportName:"default",description:"",tags:{},sourceFiles:["/Users/feipan/Desktop/\u9879\u76EE/\u6D4B\u8BD5/vue-openlayers-map-vite/src/stories/GeoJson/GeoJsonBasicExample.vue"]};const Z=`<template>
  <v-map :view="view" style="width: 100%; height: 600px">
    <v-tile tile-type="TD" />
    <v-vector :geoJson="geoJsonData" :layerStyle="layerStyle" />
  </v-map>
</template>

<script>
import { VMap, VTile, VVector } from "v-ol-map";

export default {
  name: "GeoJsonBasicExample",
  components: { VMap, VTile, VVector },
  data() {
    return {
      view: { center: [118.0894, 24.4798], zoom: 9, projection: "EPSG:4326" },
      geoJsonData: {
        type: "FeatureCollection",
        features: [
          {
            type: "Feature",
            properties: {
              id: "point-1",
              name: "\u53A6\u95E8\u5E02",
              style: {
                circle: {
                  radius: 10,
                  fill: { color: "rgba(255, 0, 0, 0.8)" },
                  stroke: { color: "#fff", width: 2 },
                },
                text: {
                  text: "\u53A6\u95E8\u5E02",
                  fill: { color: "#333" },
                  offsetY: -20,
                },
                styleFunction: function (feature, resolution, map, style) {
                  const viewZoom = map.getView().getZoom();
                  const textStyle = style.getText();
                  const properties = feature.get("style");
                  let originText = "";
                  if (properties) {
                    originText = properties.text.text;
                  }
                  if (viewZoom && textStyle) {
                    if (viewZoom <= 12) {
                      textStyle.setText("");
                    }
                    if (viewZoom >= 13) {
                      textStyle.setText(originText);
                    }
                    if (viewZoom >= 14) {
                      textStyle.setText(\`\u6839\u636E\u5C42\u7EA7\u663E\u793A\u4E0D\u540C\u5185\u5BB9,\u5F53\u524D\u5C42\u7EA7\uFF1A\${viewZoom}\u7EA7\`);
                    }
                    style.setText(textStyle);
                  }
                  return style;
                },
              },
            },
            geometry: {
              type: "Point",
              coordinates: [118.0894, 24.4798],
            },
          },
          {
            type: "Feature",
            properties: { id: "point-2", name: "\u6F33\u5DDE\u5E02" },
            geometry: {
              type: "Point",
              coordinates: [117.6469, 24.5128],
            },
          },
          {
            type: "Feature",
            properties: {
              id: "point-3",
              name: "\u6CC9\u5DDE\u5E02",
              style: {
                circle: {
                  radius: 8,
                  fill: { color: "rgba(0, 150, 0, 0.8)" },
                  stroke: { color: "#fff", width: 2 },
                },
              },
            },
            geometry: {
              type: "Point",
              coordinates: [118.5894, 24.9087],
            },
          },
        ],
      },
      layerStyle: {
        circle: {
          radius: 8,
          fill: { color: "rgba(33, 150, 243, 0.8)" },
          stroke: { color: "#fff", width: 2 },
        },
      },
    };
  },
};
<\/script>
`,h={id:"2-3",title:"\u56FE\u5C42/Vector\u77E2\u91CF\u56FE\u5C42",component:i,render:(e,{argTypes:t})=>({setup(){return{args:e}},components:{VMap:c,VVector:i},template:`
      <v-map v-bind="args.map">
        <v-vector v-bind="args.layer"></v-vector>
      </v-map>
    `}),parameters:{docs:{description:{component:""}}}},s={args:{map:T.args,layer:{features:[{id:"point1",coordinates:[118.124742,24.487405],style:{zIndex:1,icon:{scale:.6,src:new URL("data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACIAAAAvCAYAAACG2RgcAAAABGdBTUEAALGPC/xhBQAAACBjSFJNAAB6JgAAgIQAAPoAAACA6AAAdTAAAOpgAAA6mAAAF3CculE8AAAABmJLR0QA/wD/AP+gvaeTAAAGp0lEQVRYw7WYbYhcVxnHf885d952N9nYXZK4ie22NQRMG2pp9ENUqFlqpVVaEEVCwEKgSaFiMagJohjC9kOEYj9oxZi0FJO2vgSKJm2sEtRKzFuDjdo0ZTebzb4n+9Ld2bkz955z/DB3dmc3c2dmN9s/HGa4c855fvM/z3POmREWoMcOda+wTc0Pi5ItImojcBciy4LQgXWTDrpw7l2Le8vPTbxx8ok7x+udW+rp9OhvhtdJMrFblP6mEtJIcaBEr0HocA4clL/61oavWGs6/7x15eVbAvnKL8822BV371VafVuEhIigpRgotI5CCKFxBIHD00LSA08Xp7QOrHVYR+CMeX402/2jc08+ML1gkC+9PPxJlUwcVUrdo6T47UMDucBhbNGBkoLAzRmrtZBJCgldAgJn3cXQDx4/uX3lB3WDdLzU92mdajyhlLRqVZwsV3CExlXqfhNISV4EJALGgrXuuslPP/S37Wvemd9XzX/whUO961yi4QRIqwgEBrJ+PEQ1hcYx5VsC41ACCK0kMic++0LvuqogG/e/2ah041GQVqUgMI5cwWLdwiFKcg78gotgBJBWL9lwdOP+NxvjQGR56/17UWqDVmCsIx/MzYVbgckHDmsdWoETtSHdfN9eylJj5s3mn3etV023vetpEilPyBVc3U7E5ch8iUBDSpEPHKEhCCfH7j37nbsuAXgzfdJNe8AlPCXkw+oQJnRMDBeYHg8o+BZbsCTSmswKj+WrUmivcjGWnPE0hMYlVKZxN/AE4ATgM51vtaTWPnANXDqTLLoRp+x4yEhPDmdn+5iCnf3WSmhpz9C4IhE7R1kMf/yD82vfe7bjhgIk0br+YXBpKFZJnKYnihClgJUawI0rOaYnwth5CrMx0ss+sf7LgChA0MkOAKUEYyu7YY1jtD+PaKmrjfX52JiSN8ahojJRytsCiAco0foeAC0Q2IpjyY6FOEDpm9ffxeREdixgWWuy4mdaCdY60N69gPIAEaXbqaGCb1ExAa1VFZ8HORs7X6kWotjiAYLIcpzDxI8jCB3KqxxQWRs7Jk4zKSCyrAQC0cZWrWSVJ7Gbm7KVnaq0jPMdwVkDpX3EmkFEraWKmho0OT/GMi+6G8xTJqOoKcfwDIgz4XviJauCNDdrCjGZ7GIcWd7sEdTiMMFlwCnA2jB/qhZ4plGTTCg8LTc1XaElE0KmSdc0xAb+qRKIy13vPVZrQLbgWNOWqBhUa9Bqtnka2tqSZPO1zyB/tO8Y0RYvQPrzL974L0q1VxvUmFKkFQwNB8U9IFL5oacUrFqZIGeF6bytNh3O2Sv/2t76KcBXFNPMhPmpV2q6krf4FtpvT9La4pFOK7QWPE/IZBQtLR533JGqCwLA+pOvAqa0NABm6v0zLwliag3O5i0DExadUqxeneTuO1O0t6dYtTqJTikGx21dEICZ6D73YgQycx8RILX5wMCrKpn+aj2zlKve+8gcikLu9TM713wDyJc74oAwP3LluQXPuEgF17ueA8Io9pxbvAJSmw8O/lF5qS9+lI7YIP/X0zs+/mjkhi0Fn/kcCKeHLj+LsAQ31RgJzh+63Bm5YWcfz5UC0p87MPCaJNOPfBSO2MD/0+kdbV8H/HKQ+YeBBYKprvM/hJq78yLk/In//XNPNPec0qp0KpkLnY9cMtOTv1pqjHB6/PlLP/va+xSXZY4qgVgg6Dvxwj5nTf+SUVh79dqxfT+lrFJqgQCYnj90jgZjAz9YKg5/tHfP4PFDHxJtYPNV7W8JDaQ3/7r/ZZXIPF4tSK1ktYXc0dM712wDcszLjVqOEA0o9P/l8DM4O7BYJ5yzAyN/P/IMUIiDqAXigLD78K7B3FDX04vaWwSXG+l+uvvwrkEqJGi9IDMwZ7+36XiYmzy4UI4wN3Xw37s3HScmQctV+woV/SVm+wf/8bFND20Rpdvmd6h0iXcmONd3YNe3JgcuZolJ0IU4UpLpP3fkw5HTv9vqsEM1yZ0dGj71+639547EVsliQRwQXvrFUz1T3e9so5h4cR0L2asXtnUffKqHOpZkoSAQVdGFH3e87Y/0PhlziTLB9as7Lu7teJsaVXIrICWY/JnvbvxtbuTqTuaeR4E/em3n+e/f9xplx3u9qusP3wp9PSB1/09OPthw+4b9QejI9vxn18V9D56MIMpLta6lqQdEAUkgEQEoitXmRc9LP/cLUQspJqiN3gfUsUy1QAS4LYKQCuMUs8try4KVu+AimNFq7tyKI1LWSgFLbckdWWzfctWVI/8HeDod76Lvx3wAAAAldEVYdGRhdGU6Y3JlYXRlADIwMTktMDEtMDlUMDI6NTM6MTArMDg6MDAtqRnyAAAAJXRFWHRkYXRlOm1vZGlmeQAyMDE5LTAxLTA5VDAyOjUzOjEwKzA4OjAwXPShTgAAAEN0RVh0c29mdHdhcmUAL3Vzci9sb2NhbC9pbWFnZW1hZ2ljay9zaGFyZS9kb2MvSW1hZ2VNYWdpY2stNy8vaW5kZXguaHRtbL21eQoAAAAYdEVYdFRodW1iOjpEb2N1bWVudDo6UGFnZXMAMaf/uy8AAAAXdEVYdFRodW1iOjpJbWFnZTo6SGVpZ2h0ADQ3F9+avAAAABZ0RVh0VGh1bWI6OkltYWdlOjpXaWR0aAAzNDk4nUwAAAAZdEVYdFRodW1iOjpNaW1ldHlwZQBpbWFnZS9wbmc/slZOAAAAF3RFWHRUaHVtYjo6TVRpbWUAMTU0Njk3MzU5MIyLI/IAAAARdEVYdFRodW1iOjpTaXplADQ1OThCpvICBQAAAGJ0RVh0VGh1bWI6OlVSSQBmaWxlOi8vL2hvbWUvd3d3cm9vdC9uZXdzaXRlL3d3dy5lYXN5aWNvbi5uZXQvY2RuLWltZy5lYXN5aWNvbi5jbi9maWxlcy8xMTIvMTEyOTc2OS5wbmfT3rLnAAAAAElFTkSuQmCC",self.location).href}},properties:{name:"feature1",level:2}}]}}},A={parameters:{docs:{description:{story:""}}},args:{map:T.args,layer:{features:[{id:"point1",coordinates:[118.124742,24.487405],style:{zIndex:1,icon:{scale:.6,src:new URL("data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACIAAAAvCAYAAACG2RgcAAAABGdBTUEAALGPC/xhBQAAACBjSFJNAAB6JgAAgIQAAPoAAACA6AAAdTAAAOpgAAA6mAAAF3CculE8AAAABmJLR0QA/wD/AP+gvaeTAAAGn0lEQVRYw7WYX4zUVxXHP+f+fjM7s7vAQndTNNSsCMHIn0isfxO1FUrgoVjrgzGkiT4Y7UNNm/gghPhATH3QpKbxzVj1rdWEbcRQ0aaptiAUKCJYWFgRBHZYpOv+m/nN78+9x4ffzDID85uZXfAkJ/Obyb33fH7ne869NyMswE498cjAQI/dbjBbxOgmQVaDLHFxDOgsTi9ZOCPqXp/S8A+bX/3bVLdrSzeD/vnVT6/1vNxuz5ivI1IAEBGouYtiQEFTV1VQqs65l13C8x/5/bGL9wRy4vFP9A729OwzRr4rYnIYgxiTBrMWF0ZoEuOiGMnlMPkc4vsAqHPgHKoaO6cvTqr7wcMHTlYWDDK287Nrcr6OiDEbxBgQQZMEFwSotaC3x6bSNCzqeZhiEcn54BR1DufcWRfrV9Ycenesa5B/7Hh4c3/e/FE8M4jngSquEqA2aQLIAplf3PcxxWIqobU4524Fkdu2/vXTpzqCvPfYx9f29nhHxPcGxffTLFSr4JQsywJJIwimUGB+LWtvzbj4c5v/dK6pbkzjl0PbNvX1+DqCMCjGoFGMC4K2EB1NFRdU0ThGjEFgsN/JyKFND/ZlgchqtfsMrBdjasVYbSnFImhw1RB1FvEMBtYPL1++r1GR+Yfjj65b90Auf8b4fk568gvKRFtp7pSpt4iGES5O4v/GuvGTh0dHAfz6kAEvt0cgJ76HhmFbCGsd5ak5grkqSZRgrcXP+RT7CvQP9OJ5pvVEVbQaIb6HJEmuPye7gW8CKgD7P/XRBzYP+NdACqZYSIszgyOYC5iamEIbQBNrb7+0MSwfWkpvfyHzRUyxgAuqANXT5dlVT75z/X0DyLolZjukO6bGcSZEtVxlamKqFlDm3YggNUeVqZvTBOUwW8poXsrC2p7+HYAYQHwjW1PUtEhbTraOmVszGJG7XIxgGlyMMPP+LM66LG3BpPL5RrfUQYyHbAAQz7SVRFSbAtbdawGHKsFcdlbEeAB4YjYCxq/JOtypTZMowZjWJ4Ka1sUZR0mbFdOAIgwD4qfPshTIlAVA4wST0Q210/bu35NskHosgSV1EFRJ37VNyxoj2ZtbRqYkI1M1+vqnhdo+onBDYFWbPJLr7yMJgtYBMwD93gKdTJGb8yCJ0/N5I21B8gNLsFHrHdS0VoaeZf2QRG1BEuUioAZwodOjncjzvQW8fA7jm7tcfA/jNbuXz5Hv7emYkdDao3UQvV4ND3aaYMtl+h5amW7P3p1uEL/Z+1c9iJ2rdAS5GkUHqW3xAhTGtm18z4PhdpNMXy8UigSlm01bvE1uSybG0LtyCIIAV2kPkiiX1715/mNA1ZDKayuJfbkTvStXoBqwZPWHKAytwCsW0mPd9/GLBYqDK1g6vKorCIBy4l4BbF0aAHtyuvJrBNtpsitXiEo38H1D3weGWLp2mGUffoi+lUP4niEqTXQFAdjT09GvaiDz9xEBes5tXf9KwZid3azSBNftfaTBAqu/2/CX0a8BYWNGFEguV8MXFrziIu1qJXwBSGqxm66KbsfbY8dCdW/8vyEip2/sOHH5GDB/PDeBAMnl2fhH3KebaobpWCV+vpaNliAAdvvRC0cC5zruK4u1qnUHHz9+6a/Q3Bh3gjggPjVd3quw8ArslAqlemSysod07aZbU6vj0e46fnm0bN3P7zfIdGJf/NbZaxdIZWmyViAOiH8xPvFDq4zfLwjr+PfPxko/oaFTOoEA2J+euzVZisLv3y+QUpjs+eWNuRlovWlmgSiQfP7PF/YH1o3cK0TVupEvHh17lbQ2WnZkmysUDoj2j08+59DSYiGsUhr5z+xzQMQdBdotiALJ3nOlG1eC8BkWt7folSB6Zu+50g1aFGi3IPMwX3rr4mtz1r20UIq52L302LFLr5FRoI3mdfNWgF4Lq29vHVq2xRP54F0D3N0Zj1RP7h4rfePCbFSGzqd6p4zUzR4Yn505ODG5y6ETnQY7ZeJQaXbXgfHZzC5ZLIgCybN/H79ydjp8StPCyxoYnZkLn3p2dPwKXUiyUBCoddGXj108fC2Iv51xibLXwug7T57412E6dMm9gNRhwi+8df63Vyvx043nkVPi62H89CNHLv2G9LLTNQR0+Ydvi7E+0HPgM2seXbe08GONYkZn4u/tfPfSmzWIxlbtSppuQAyQB3I1AEPabX7t93xtXFTzhLRAXe05pguZOoEIsKIGIS3mGW7L6xqCNWZBazCT7bJzLxmRBq8HrPt9z8hixzZaVzXyP6BgM8Qy17HzAAAAJXRFWHRkYXRlOmNyZWF0ZQAyMDE5LTAxLTA5VDAyOjUzOjE1KzA4OjAwf5E2VQAAACV0RVh0ZGF0ZTptb2RpZnkAMjAxOS0wMS0wOVQwMjo1MzoxNSswODowMA7MjukAAABDdEVYdHNvZnR3YXJlAC91c3IvbG9jYWwvaW1hZ2VtYWdpY2svc2hhcmUvZG9jL0ltYWdlTWFnaWNrLTcvL2luZGV4Lmh0bWy9tXkKAAAAGHRFWHRUaHVtYjo6RG9jdW1lbnQ6OlBhZ2VzADGn/7svAAAAF3RFWHRUaHVtYjo6SW1hZ2U6OkhlaWdodAA0NxffmrwAAAAWdEVYdFRodW1iOjpJbWFnZTo6V2lkdGgAMzQ5OJ1MAAAAGXRFWHRUaHVtYjo6TWltZXR5cGUAaW1hZ2UvcG5nP7JWTgAAABd0RVh0VGh1bWI6Ok1UaW1lADE1NDY5NzM1OTX84dd9AAAAEXRFWHRUaHVtYjo6U2l6ZQA0NjE3Qj3M4JwAAABidEVYdFRodW1iOjpVUkkAZmlsZTovLy9ob21lL3d3d3Jvb3QvbmV3c2l0ZS93d3cuZWFzeWljb24ubmV0L2Nkbi1pbWcuZWFzeWljb24uY24vZmlsZXMvMTEyLzExMjk4NjUucG5n4GYvDwAAAABJRU5ErkJggg==",self.location).href}},properties:{name:"feature1",level:2}}],modify:!0}},render:(e,{argTypes:t})=>({setup(){return{args:e}},components:{VMap:c,VVector:i,VTile:B},template:`
      <v-map v-bind="args.map">
        <v-tile tile-type="BD"></v-tile>
        <v-vector v-bind="args.layer"></v-vector>
      </v-map>
    `})},n={parameters:{docs:{description:{story:"GeoJSON \u57FA\u7840\u793A\u4F8B\u3002\u5C55\u793A\u6837\u5F0F\u4F18\u5148\u7EA7\uFF1AFeature.properties.style\uFF08\u7EA2\u8272/\u7EFF\u8272\u70B9\uFF09> layerStyle\uFF08\u84DD\u8272\u70B9\uFF09"},source:{language:"html",code:Z}}},render:()=>({components:{GeoJsonBasicExample:S},template:"<GeoJsonBasicExample />"})};var m,g,v;s.parameters={...s.parameters,docs:{...(m=s.parameters)==null?void 0:m.docs,source:{originalSource:`{
  args: {
    map: MapStoriies.args,
    layer: {
      features: [{
        id: "point1",
        coordinates: [118.124742, 24.487405],
        style: {
          zIndex: 1,
          icon: {
            scale: 0.6,
            src: new URL("../assets/img/point_1.png", import.meta.url).href
          }
        },
        properties: {
          name: "feature1",
          level: 2
        }
      }]
    }
  }
}`,...(v=(g=s.parameters)==null?void 0:g.docs)==null?void 0:v.source}}};var y,f,F;A.parameters={...A.parameters,docs:{...(y=A.parameters)==null?void 0:y.docs,source:{originalSource:`{
  parameters: {
    docs: {
      description: {
        story: ""
      }
    }
  },
  args: {
    map: MapStoriies.args,
    layer: {
      features: [{
        id: "point1",
        coordinates: [118.124742, 24.487405],
        style: {
          zIndex: 1,
          icon: {
            scale: 0.6,
            src: new URL("../assets/img/point_2.png", import.meta.url).href
          }
        },
        properties: {
          name: "feature1",
          level: 2
        }
      }],
      modify: true
    }
  },
  render: (args, {
    argTypes
  }) => ({
    setup() {
      return {
        args
      };
    },
    // props: Object.keys(argTypes),
    components: {
      VMap,
      VVector,
      VTile
    },
    template: \`
      <v-map v-bind="args.map">
        <v-tile tile-type="BD"></v-tile>
        <v-vector v-bind="args.layer"></v-vector>
      </v-map>
    \`
  })
}`,...(F=(f=A.parameters)==null?void 0:f.docs)==null?void 0:F.source}}};var V,E,x,b,W;n.parameters={...n.parameters,docs:{...(V=n.parameters)==null?void 0:V.docs,source:{originalSource:`{
  parameters: {
    docs: {
      description: {
        story: "GeoJSON \u57FA\u7840\u793A\u4F8B\u3002\u5C55\u793A\u6837\u5F0F\u4F18\u5148\u7EA7\uFF1AFeature.properties.style\uFF08\u7EA2\u8272/\u7EFF\u8272\u70B9\uFF09> layerStyle\uFF08\u84DD\u8272\u70B9\uFF09"
      },
      source: {
        language: "html",
        code: GeoJsonBasicExampleRaw
      }
    }
  },
  render: () => ({
    components: {
      GeoJsonBasicExample
    },
    template: "<GeoJsonBasicExample />"
  })
}`,...(x=(E=n.parameters)==null?void 0:E.docs)==null?void 0:x.source},description:{story:`GeoJSON \u57FA\u7840\u793A\u4F8B

\u5C55\u793A\u5982\u4F55\u4F7F\u7528 geoJson \u5C5E\u6027\u52A0\u8F7D GeoJSON \u683C\u5F0F\u7684\u70B9\u6570\u636E\uFF0C
\u4EE5\u53CA\u8981\u7D20\u7EA7\u522B\u6837\u5F0F\u4E0E\u56FE\u5C42\u7EDF\u4E00\u6837\u5F0F\u7684\u4F18\u5148\u7EA7\u5173\u7CFB`,...(W=(b=n.parameters)==null?void 0:b.docs)==null?void 0:W.description}}};const J=["Default","Modify","GeoJsonBasic"],D=Object.freeze(Object.defineProperty({__proto__:null,default:h,Default:s,Modify:A,GeoJsonBasic:n,__namedExportsOrder:J},Symbol.toStringTag,{value:"Module"}));export{s as D,n as G,A as M,D as V};
