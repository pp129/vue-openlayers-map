import{n as I,V as E,a as F,h as u}from"./index.76fcd3ae.js";var C=function(){var e=this,n=e.$createElement,t=e._self._c||n;return t("div",{staticClass:"image-example"},[t("v-map",{staticStyle:{width:"100%",height:"600px"},attrs:{view:e.view}},[t("v-tile",{attrs:{"tile-type":"TD"}}),t("v-image",{attrs:{"source-type":"Static","image-url":e.imageUrl,"image-extent":e.imageExtent,opacity:.7}})],1)],1)},V=[];const b={name:"ImageExample",components:{VMap:E,VTile:F,VImage:u},data(){return{view:{center:[118.0894,24.4798],zoom:13,projection:"EPSG:4326"},imageUrl:"https://openlayers.org/en/latest/examples/data/kml/2012_Earthquakes_Mag5.png",imageExtent:[117.9,24.3,118.3,24.7]}}},g={};var M=I(b,C,V,!1,R,null,null,null);function R(e){for(let n in g)this[n]=g[n]}const A=function(){return M.exports}();M.exports.__docgenInfo={displayName:"ImageExample",exportName:"default",description:"",tags:{},sourceFiles:["/Users/feipan/Desktop/\u9879\u76EE/\u6D4B\u8BD5/vue-openlayers-map-vite/src/stories/Image/ImageExample.vue"]};const W=`<template>
  <div class="image-example">
    <v-map :view="view" style="width: 100%; height: 600px">
      <v-tile tile-type="TD" />
      <v-image source-type="Static" :image-url="imageUrl" :image-extent="imageExtent" :opacity="0.7" />
    </v-map>
  </div>
</template>

<script>
import { VMap, VTile, VImage } from "@/packages";

export default {
  name: "ImageExample",
  components: { VMap, VTile, VImage },
  data() {
    return {
      view: { center: [118.0894, 24.4798], zoom: 13, projection: "EPSG:4326" },
      imageUrl: "https://openlayers.org/en/latest/examples/data/kml/2012_Earthquakes_Mag5.png",
      imageExtent: [117.9, 24.3, 118.3, 24.7],
    };
  },
};
<\/script>
`;var k=function(){var e=this,n=e.$createElement,t=e._self._c||n;return t("div",{staticStyle:{width:"100%",height:"100%",position:"relative"}},[t("div",{staticClass:"tool"},[t("div",{staticClass:"item"},[t("label",[e._v("\u66F4\u65B0WMS\u53C2\u6570\uFF0C\u662F\u5426\u53EA\u770B\u62E5\u5835\u8DEF\u6BB5")]),t("input",{directives:[{name:"model",rawName:"v-model",value:e.onlyShowCongested,expression:"onlyShowCongested"}],attrs:{type:"checkbox"},domProps:{checked:Array.isArray(e.onlyShowCongested)?e._i(e.onlyShowCongested,null)>-1:e.onlyShowCongested},on:{change:[function(m){var s=e.onlyShowCongested,r=m.target,c=!!r.checked;if(Array.isArray(s)){var i=null,a=e._i(s,i);r.checked?a<0&&(e.onlyShowCongested=s.concat([i])):a>-1&&(e.onlyShowCongested=s.slice(0,a).concat(s.slice(a+1)))}else e.onlyShowCongested=c},e.updateParams]}})])]),t("v-map",{ref:"map",attrs:{view:e.view},on:{click:e.click}},[t("v-tile",{attrs:{"tile-type":"BD","z-index":0}}),t("v-image",{ref:"wms",attrs:{"source-type":"WMS",wms:e.wms,"z-index":1,visible:e.wms.visible}})],1)],1)},P=[];const O={name:"ImageWMS",components:{VMap:E,VTile:F,VImage:u},data(){return{view:{city:"\u53A6\u95E8",zoom:12},onlyShowCongested:!1,wms:{visible:!0,url:"http://36.248.238.35:8888/wms-api/xm/wms",params:{VERSION:"1.1.1",FORMAT:"image/png",STYLES:"",LAYERS:"xm:gd_route_clean"},serverType:"geoserver",ratio:1,crossOrigin:"anonymous"}}},methods:{refresh(){this.timer=setInterval(()=>{this.updateParamsByTime()},1e4)},updateParams(){var n;const e=(n=this.$refs.wms)==null?void 0:n.layer.getSource();!e||e.updateParams({CQL_FILTER:this.onlyShowCongested?"state in (3,4)":""})},updateParamsByTime(){var n;const e=(n=this.$refs.wms)==null?void 0:n.layer.getSource();!e||e.updateParams({TIME:new Date().getTime()})},click(e,n){var a;const t=(a=this.$refs.wms)==null?void 0:a.layer;if(!t)return;const m=t.getSource(),s=t.getVisible();if(!m||!s)return;const r=n.getView(),c=r.getResolution();if(!c)return;const i=m.getFeatureInfoUrl(e.coordinate,c,r.getProjection().getCode(),{INFO_FORMAT:"application/json",FEATURE_COUNT:10});i&&fetch(i).then(p=>p.json()).then(p=>{})}},mounted(){this.refresh()}},d={};var T=I(O,k,P,!1,$,"4403afb5",null,null);function $(e){for(let n in d)this[n]=d[n]}const j=function(){return T.exports}();T.exports.__docgenInfo={displayName:"ImageWMS",exportName:"default",description:"",tags:{},sourceFiles:["/Users/feipan/Desktop/\u9879\u76EE/\u6D4B\u8BD5/vue-openlayers-map-vite/src/stories/ImageWMS/index.vue"]};const U=`<template>
  <div style="width: 100%; height: 100%; position: relative">
    <div class="tool">
      <div class="item">
        <label>\u66F4\u65B0WMS\u53C2\u6570\uFF0C\u662F\u5426\u53EA\u770B\u62E5\u5835\u8DEF\u6BB5</label>
        <input type="checkbox" v-model="onlyShowCongested" @change="updateParams" />
      </div>
    </div>
    <v-map ref="map" :view="view" @click="click">
      <v-tile tile-type="BD" :z-index="0"></v-tile>
      <v-image ref="wms" source-type="WMS" :wms="wms" :z-index="1" :visible="wms.visible"></v-image>
    </v-map>
  </div>
</template>

<script>
import { VMap, VTile, VImage } from "v-ol-map";

export default {
  name: "ImageWMS",
  components: {
    VMap,
    VTile,
    VImage,
  },
  data() {
    return {
      view: {
        city: "\u53A6\u95E8",
        zoom: 12,
      },
      onlyShowCongested: false,
      wms: {
        visible: true,
        url: "http://36.248.238.35:8888/wms-api/xm/wms",
        params: {
          VERSION: "1.1.1",
          FORMAT: "image/png",
          STYLES: "",
          LAYERS: "xm:gd_route_clean",
        },
        serverType: "geoserver",
        ratio: 1,
        crossOrigin: "anonymous",
      },
    };
  },
  methods: {
    refresh() {
      console.log("\u5237\u65B0\u6570\u636E");
      this.timer = setInterval(() => {
        console.log("\u5237\u65B0\u6570\u636E");
        this.updateParamsByTime();
      }, 10000);
    },
    updateParams() {
      const source = this.$refs.wms?.layer.getSource();
      if (!source) return;
      // \u66F4\u65B0\u53C2\u6570
      source.updateParams({ CQL_FILTER: this.onlyShowCongested ? "state in (3,4)" : "" });
    },
    updateParamsByTime() {
      const source = this.$refs.wms?.layer.getSource();
      if (!source) return;
      // \u5F3A\u5236\u89E6\u53D1\u66F4\u65B0
      source.updateParams({ TIME: new Date().getTime() });
    },
    // \u70B9\u51FB\u4E8B\u4EF6,\u83B7\u53D6\u56FE\u5C42\u8981\u7D20\u4FE1\u606F\u793A\u4F8B
    click(evt, map) {
      const layer = this.$refs.wms?.layer;
      if (!layer) return;
      const wmsSource = layer.getSource();
      const visible = layer.getVisible();
      if (!wmsSource || !visible) return;
      const view = map.getView();
      const viewResolution = view.getResolution();
      if (!viewResolution) return;
      const url = wmsSource.getFeatureInfoUrl(evt.coordinate, viewResolution, view.getProjection().getCode(), {
        INFO_FORMAT: "application/json",
        FEATURE_COUNT: 10,
      });
      if (url) {
        fetch(url)
          .then((response) => response.json())
          .then((data) => {
            console.log(data);
          });
      }
    },
  },
  mounted() {
    this.refresh();
  },
};
<\/script>

<style scoped>
.tool {
  position: absolute;
  top: 10px;
  left: 10px;
  z-index: 100;
  background-color: rgba(255, 255, 255, 0.8);
  padding: 10px;
  box-shadow: 0 0 10px rgba(0, 0, 0, 0.5);
  border-radius: 5px;
}
</style>
`,z={id:"2-4",title:"\u56FE\u5C42/Image\u56FE\u7247\u56FE\u5C42",component:u,parameters:{docs:{description:{component:""}}}},o={parameters:{docs:{description:{story:"\u9759\u6001\u56FE\u7247\u56FE\u5C42\u793A\u4F8B\u3002\u5728\u6307\u5B9A\u8303\u56F4\u5185\u663E\u793A\u56FE\u7247"},source:{language:"html",code:W}}},render:()=>({components:{ImageExample:A},template:"<ImageExample />"})},l={parameters:{docs:{description:{story:"WMS\u56FE\u7247\u56FE\u5C42\u793A\u4F8B\u3002\u5728\u6307\u5B9A\u8303\u56F4\u5185\u663E\u793AWMS\u56FE\u7247"},source:{language:"html",code:U}}},render:()=>({components:{ImageWms:j},template:"<ImageWms />"})};var v,h,y,w,_;o.parameters={...o.parameters,docs:{...(v=o.parameters)==null?void 0:v.docs,source:{originalSource:`{
  parameters: {
    docs: {
      description: {
        story: "\u9759\u6001\u56FE\u7247\u56FE\u5C42\u793A\u4F8B\u3002\u5728\u6307\u5B9A\u8303\u56F4\u5185\u663E\u793A\u56FE\u7247"
      },
      source: {
        language: "html",
        code: ImageExampleRaw
      }
    }
  },
  render: () => ({
    components: {
      ImageExample
    },
    template: "<ImageExample />"
  })
}`,...(y=(h=o.parameters)==null?void 0:h.docs)==null?void 0:y.source},description:{story:"\u56FE\u7247\u56FE\u5C42\u57FA\u7840\u793A\u4F8B",...(_=(w=o.parameters)==null?void 0:w.docs)==null?void 0:_.description}}};var f,S,x;l.parameters={...l.parameters,docs:{...(f=l.parameters)==null?void 0:f.docs,source:{originalSource:`{
  parameters: {
    docs: {
      description: {
        story: "WMS\u56FE\u7247\u56FE\u5C42\u793A\u4F8B\u3002\u5728\u6307\u5B9A\u8303\u56F4\u5185\u663E\u793AWMS\u56FE\u7247"
      },
      source: {
        language: "html",
        code: ImageWmsRaw
      }
    }
  },
  render: () => ({
    components: {
      ImageWms
    },
    template: "<ImageWms />"
  })
}`,...(x=(S=l.parameters)==null?void 0:S.docs)==null?void 0:x.source}}};const B=["Default","ImageWMS"],N=Object.freeze(Object.defineProperty({__proto__:null,default:z,Default:o,ImageWMS:l,__namedExportsOrder:B},Symbol.toStringTag,{value:"Module"}));export{o as D,l as I,N as V};
