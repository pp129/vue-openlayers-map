import{n as v,V as d,a as u}from"./index.76fcd3ae.js";import{D as I}from"./VMap.stories.ccd9cff5.js";var $=function(){var e=this,n=e.$createElement,t=e._self._c||n;return t("v-map",{staticStyle:{width:"100%",height:"600px"},attrs:{view:e.view}},[t("v-tile",{attrs:{"tile-type":"TD"}})],1)},O=[];const P={name:"TileDefaultExample",components:{VMap:d,VTile:u},data(){return{view:{center:[118.1689,24.6478],zoom:10}}}},y={};var z=v(P,$,O,!1,X,null,null,null);function X(e){for(let n in y)this[n]=y[n]}const b=function(){return z.exports}();z.exports.__docgenInfo={displayName:"TileDefaultExample",exportName:"default",description:"",tags:{},sourceFiles:["/Users/feipan/Desktop/\u9879\u76EE/\u6D4B\u8BD5/vue-openlayers-map-vite/src/stories/Tile/TileDefaultExample.vue"]};const Z=`<template>
  <v-map :view="view" style="width: 100%; height: 600px">
    <v-tile tile-type="TD" />
  </v-map>
</template>

<script>
import { VMap, VTile } from "@/packages";

export default {
  name: "TileDefaultExample",
  components: { VMap, VTile },
  data() {
    return {
      view: {
        center: [118.1689, 24.6478],
        zoom: 10,
      },
    };
  },
};
<\/script>
`;var k=function(){var e=this,n=e.$createElement,t=e._self._c||n;return t("v-map",{staticStyle:{width:"100%",height:"600px"},attrs:{view:e.view}},[t("v-tile",{attrs:{"tile-type":"XYZ",xyz:e.xyzOptions}})],1)},j=[];const B={name:"TileXYZExample",components:{VMap:d,VTile:u},data(){return{view:{center:[118.1689,24.6478],zoom:10,projection:"EPSG:4326"},xyzOptions:{url:"https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}",projection:"EPSG:4326",crossOrigin:"anonymous"}}}},_={};var W=v(B,k,j,!1,N,null,null,null);function N(e){for(let n in _)this[n]=_[n]}const U=function(){return W.exports}();W.exports.__docgenInfo={displayName:"TileXYZExample",exportName:"default",description:"",tags:{},sourceFiles:["/Users/feipan/Desktop/\u9879\u76EE/\u6D4B\u8BD5/vue-openlayers-map-vite/src/stories/Tile/TileXYZExample.vue"]};const G=`<template>
  <v-map :view="view" style="width: 100%; height: 600px">
    <v-tile tile-type="XYZ" :xyz="xyzOptions" />
  </v-map>
</template>

<script>
import { VMap, VTile } from "@/packages";

export default {
  name: "TileXYZExample",
  components: { VMap, VTile },
  data() {
    return {
      view: {
        center: [118.1689, 24.6478],
        zoom: 10,
        projection: "EPSG:4326",
      },
      // XYZ \u74E6\u7247\u914D\u7F6E
      xyzOptions: {
        url: "https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}",
        projection: "EPSG:4326",
        crossOrigin: "anonymous",
      },
    };
  },
};
<\/script>
`;var L=function(){var e=this,n=e.$createElement,t=e._self._c||n;return t("div",{staticStyle:{width:"100%",height:"100%",position:"relative"}},[t("div",{staticClass:"tool"},[t("div",{staticClass:"item"},[t("label",[e._v("\u66F4\u65B0WMS\u53C2\u6570\uFF0C\u662F\u5426\u53EA\u770B\u62E5\u5835\u8DEF\u6BB5")]),t("input",{directives:[{name:"model",rawName:"v-model",value:e.onlyShowCongested,expression:"onlyShowCongested"}],attrs:{type:"checkbox"},domProps:{checked:Array.isArray(e.onlyShowCongested)?e._i(e.onlyShowCongested,null)>-1:e.onlyShowCongested},on:{change:[function(r){var o=e.onlyShowCongested,l=r.target,m=!!l.checked;if(Array.isArray(o)){var c=null,s=e._i(o,c);l.checked?s<0&&(e.onlyShowCongested=o.concat([c])):s>-1&&(e.onlyShowCongested=o.slice(0,s).concat(o.slice(s+1)))}else e.onlyShowCongested=m},e.updateParams]}})])]),t("v-map",{ref:"map",attrs:{view:e.view},on:{click:e.click,load:e.refresh}},[t("v-tile",{attrs:{"tile-type":"BD"}}),t("v-tile",{ref:"wms",attrs:{"tile-type":"WMS",wms:e.wms,"z-index":1}})],1)],1)},Q=[];const q={name:"TileWMS",components:{VMap:d,VTile:u},props:{},data(){return{view:{city:"\u53A6\u95E8",zoom:12},onlyShowCongested:!1,wms:{url:"http://36.248.238.35:8888/wms-api/xm/wms",params:{FORMAT:"image/png",STYLES:"",LAYERS:"xm:gd_route_clean",exceptions:"application/vnd.ogc.se_inimage",tiled:!0},serverType:"geoserver",ratio:1,crossOrigin:"anonymous"}}},methods:{refresh(){this.timer=setInterval(()=>{this.updateParamsByTime()},1e4)},updateParams(){var n;const e=(n=this.$refs.wms)==null?void 0:n.layer.getSource();!e||e.updateParams({CQL_FILTER:this.onlyShowCongested?"state in (3,4)":""})},updateParamsByTime(){var n;const e=(n=this.$refs.wms)==null?void 0:n.layer.getSource();!e||e.updateParams({TIME:new Date().getTime()})},click(e,n){var s;const t=(s=this.$refs.wms)==null?void 0:s.layer;if(!t)return;const r=t.getSource(),o=t.getVisible();if(!r||!o)return;const l=n.getView(),m=l.getResolution();if(!m)return;const c=r.getFeatureInfoUrl(e.coordinate,m,l.getProjection().getCode(),{INFO_FORMAT:"application/json",FEATURE_COUNT:10});c&&fetch(c).then(g=>g.json()).then(g=>{})}}},f={};var Y=v(q,L,Q,!1,H,"de6285a0",null,null);function H(e){for(let n in f)this[n]=f[n]}const J=function(){return Y.exports}();Y.exports.__docgenInfo={displayName:"TileWMS",exportName:"default",description:"",tags:{},sourceFiles:["/Users/feipan/Desktop/\u9879\u76EE/\u6D4B\u8BD5/vue-openlayers-map-vite/src/stories/TileWMS/index.vue"]};const K=`<template>
  <div style="width: 100%; height: 100%; position: relative">
    <div class="tool">
      <div class="item">
        <label>\u66F4\u65B0WMS\u53C2\u6570\uFF0C\u662F\u5426\u53EA\u770B\u62E5\u5835\u8DEF\u6BB5</label>
        <input type="checkbox" v-model="onlyShowCongested" @change="updateParams" />
      </div>
    </div>
    <v-map ref="map" :view="view" @click="click" @load="refresh">
      <v-tile tile-type="BD"></v-tile>
      <v-tile ref="wms" tile-type="WMS" :wms="wms" :z-index="1"></v-tile>
    </v-map>
  </div>
</template>

<script>
import { VMap, VTile } from "v-ol-map";

export default {
  name: "TileWMS",
  components: { VMap, VTile },
  props: {},
  data() {
    return {
      view: {
        city: "\u53A6\u95E8",
        zoom: 12,
      },
      onlyShowCongested: false,
      wms: {
        url: "http://36.248.238.35:8888/wms-api/xm/wms",
        params: {
          FORMAT: "image/png",
          STYLES: "",
          LAYERS: "xm:gd_route_clean",
          exceptions: "application/vnd.ogc.se_inimage",
          tiled: true,
        },
        serverType: "geoserver",
        ratio: 1,
        crossOrigin: "anonymous",
      },
    };
  },
  methods: {
    refresh() {
      console.log("\u5237\u65B0\u6570\u636E");
      this.timer = setInterval(() => {
        console.log("\u5237\u65B0\u6570\u636E");
        this.updateParamsByTime();
      }, 10000);
    },
    updateParams() {
      const source = this.$refs.wms?.layer.getSource();
      if (!source) return;
      // \u66F4\u65B0\u53C2\u6570
      source.updateParams({ CQL_FILTER: this.onlyShowCongested ? "state in (3,4)" : "" });
    },
    updateParamsByTime() {
      const source = this.$refs.wms?.layer.getSource();
      if (!source) return;
      // \u5F3A\u5236\u89E6\u53D1\u66F4\u65B0
      source.updateParams({ TIME: new Date().getTime() });
    },
    // \u70B9\u51FB\u4E8B\u4EF6,\u83B7\u53D6\u56FE\u5C42\u8981\u7D20\u4FE1\u606F\u793A\u4F8B
    click(evt, map) {
      const layer = this.$refs.wms?.layer;
      if (!layer) return;
      const wmsSource = layer.getSource();
      const visible = layer.getVisible();
      if (!wmsSource || !visible) return;
      const view = map.getView();
      const viewResolution = view.getResolution();
      if (!viewResolution) return;
      const url = wmsSource.getFeatureInfoUrl(evt.coordinate, viewResolution, view.getProjection().getCode(), {
        INFO_FORMAT: "application/json",
        FEATURE_COUNT: 10,
      });
      if (url) {
        fetch(url)
          .then((response) => response.json())
          .then((data) => {
            console.log(data);
          });
      }
    },
  },
};
<\/script>

<style scoped>
.tool {
  position: absolute;
  top: 10px;
  left: 10px;
  z-index: 100;
  background-color: rgba(255, 255, 255, 0.8);
  padding: 10px;
  box-shadow: 0 0 10px rgba(0, 0, 0, 0.5);
  border-radius: 5px;
}
</style>
`,ee={id:"2-2",title:"\u56FE\u5C42/Tile\u74E6\u7247\u56FE\u5C42",component:u,render:(e,{argTypes:n})=>({setup(){const t=I.args,r=e.tileType,o=e.xyz;return{view:t.view,tileType:r,xyz:o}},components:{VMap:d,VTile:u},template:`
      <v-map :view="view">
        <v-tile :tile-type="tileType" :xyz="xyz"></v-tile>
      </v-map>
    `}),parameters:{docs:{description:{component:""}}}},a={parameters:{docs:{description:{story:"\u4F7F\u7528\u5929\u5730\u56FE\u4F5C\u4E3A\u5E95\u56FE"},source:{language:"html",code:Z}}},render:()=>({components:{TileDefaultExample:b},template:"<TileDefaultExample />"})},i={parameters:{docs:{description:{story:"\u4F7F\u7528\u81EA\u5B9A\u4E49 XYZ \u74E6\u7247\u670D\u52A1\uFF08ArcGIS World Imagery\uFF09"},source:{language:"html",code:G}}},render:()=>({components:{TileXYZExample:U},template:"<TileXYZExample />"})},p={parameters:{docs:{description:{story:"\u4F7F\u7528 WMS \u670D\u52A1"},source:{language:"html",code:K}}},render:()=>({components:{TileWMS:J},template:"<TileWMS />"})};var w,h,T,x,S;a.parameters={...a.parameters,docs:{...(w=a.parameters)==null?void 0:w.docs,source:{originalSource:`{
  parameters: {
    docs: {
      description: {
        story: "\u4F7F\u7528\u5929\u5730\u56FE\u4F5C\u4E3A\u5E95\u56FE"
      },
      source: {
        language: "html",
        code: TileDefaultExampleRaw
      }
    }
  },
  render: () => ({
    components: {
      TileDefaultExample
    },
    template: "<TileDefaultExample />"
  })
}`,...(T=(h=a.parameters)==null?void 0:h.docs)==null?void 0:T.source},description:{story:"\u9ED8\u8BA4\u793A\u4F8B - \u5929\u5730\u56FE",...(S=(x=a.parameters)==null?void 0:x.docs)==null?void 0:S.description}}};var E,F,M,A,D;i.parameters={...i.parameters,docs:{...(E=i.parameters)==null?void 0:E.docs,source:{originalSource:`{
  parameters: {
    docs: {
      description: {
        story: "\u4F7F\u7528\u81EA\u5B9A\u4E49 XYZ \u74E6\u7247\u670D\u52A1\uFF08ArcGIS World Imagery\uFF09"
      },
      source: {
        language: "html",
        code: TileXYZExampleRaw
      }
    }
  },
  render: () => ({
    components: {
      TileXYZExample
    },
    template: "<TileXYZExample />"
  })
}`,...(M=(F=i.parameters)==null?void 0:F.docs)==null?void 0:M.source},description:{story:`XYZ \u74E6\u7247\u793A\u4F8B

\u5C55\u793A\u5982\u4F55\u4F7F\u7528\u81EA\u5B9A\u4E49 XYZ \u74E6\u7247\u670D\u52A1`,...(D=(A=i.parameters)==null?void 0:A.docs)==null?void 0:D.description}}};var V,C,R;p.parameters={...p.parameters,docs:{...(V=p.parameters)==null?void 0:V.docs,source:{originalSource:`{
  parameters: {
    docs: {
      description: {
        story: "\u4F7F\u7528 WMS \u670D\u52A1"
      },
      source: {
        language: "html",
        code: TileWMSRaw
      }
    }
  },
  render: () => ({
    components: {
      TileWMS
    },
    template: "<TileWMS />"
  })
}`,...(R=(C=p.parameters)==null?void 0:C.docs)==null?void 0:R.source}}};const ne=["Default","XYZ","WMS"],se=Object.freeze(Object.defineProperty({__proto__:null,default:ee,Default:a,XYZ:i,WMS:p,__namedExportsOrder:ne},Symbol.toStringTag,{value:"Module"}));export{a as D,se as V,p as W,i as X};
