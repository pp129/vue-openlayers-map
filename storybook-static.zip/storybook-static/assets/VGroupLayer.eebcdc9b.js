import{j as o}from"./jsx-runtime.d19f6329.js";import{M as n,C as p,b as i}from"./index.6b7544c1.js";import{V as x,D as c}from"./VGroupLayer.stories.6b771ea5.js";import{u as t}from"./index.912ed65d.js";import"./iframe.9b02d578.js";import"../sb-preview/runtime.js";import"./_commonjsHelpers.712cc82f.js";import"./index.d0b9ec93.js";import"./index.6eeffd5a.js";import"./index.7e22da21.js";import"./index.76fcd3ae.js";function s(r){const e=Object.assign({h1:"h1",p:"p",pre:"pre",code:"code",h2:"h2",blockquote:"blockquote"},t(),r.components);return o.exports.jsxs(o.exports.Fragment,{children:[o.exports.jsx(n,{of:x}),`
`,o.exports.jsx(e.h1,{id:"v-group-layer",children:"v-group-layer"}),`
`,o.exports.jsx(e.p,{children:"\u56FE\u5C42\u7EC4\u7EC4\u4EF6\uFF0C\u7528\u4E8E\u5C06\u591A\u4E2A\u56FE\u5C42\u7EC4\u5408\u5728\u4E00\u8D77\u7EDF\u4E00\u7BA1\u7406\u3002"}),`
`,o.exports.jsx(e.pre,{children:o.exports.jsx(e.code,{className:"language-js",children:`import { VMap, VGroupLayer, VTile, VVector } from "v-ol-map";
`})}),`
`,o.exports.jsx(e.h2,{id:"\u57FA\u7840\u793A\u4F8B",children:"\u57FA\u7840\u793A\u4F8B"}),`
`,o.exports.jsxs(e.blockquote,{children:[`
`,o.exports.jsx(e.p,{children:"\u56FE\u5C42\u7EC4\u5305\u542B\u591A\u4E2A\u77E2\u91CF\u56FE\u5C42\uFF0C\u53EF\u7EDF\u4E00\u63A7\u5236\u53EF\u89C1\u6027\u548C\u900F\u660E\u5EA6"}),`
`]}),`
`,o.exports.jsx(p,{of:c}),`
`,o.exports.jsx(e.h2,{id:"docs",children:"Docs"}),`
`,o.exports.jsx(i,{})]})}function V(r={}){const{wrapper:e}=Object.assign({},t(),r.components);return e?o.exports.jsx(e,Object.assign({},r,{children:o.exports.jsx(s,r)})):s(r)}export{V as default};
