import{j as o}from"./jsx-runtime.d19f6329.js";import{M as n,C as p,b as i}from"./index.6b7544c1.js";import{V as x,D as a}from"./VDraw.stories.78c81bb9.js";import{u as t}from"./index.912ed65d.js";import"./iframe.9b02d578.js";import"../sb-preview/runtime.js";import"./_commonjsHelpers.712cc82f.js";import"./index.d0b9ec93.js";import"./index.6eeffd5a.js";import"./index.7e22da21.js";import"./index.76fcd3ae.js";function r(s){const e=Object.assign({h1:"h1",p:"p",pre:"pre",code:"code",h2:"h2",blockquote:"blockquote"},t(),s.components);return o.exports.jsxs(o.exports.Fragment,{children:[o.exports.jsx(n,{of:x}),`
`,o.exports.jsx(e.h1,{id:"v-draw",children:"v-draw"}),`
`,o.exports.jsx(e.p,{children:"\u7ED1\u5236\u5DE5\u5177\u7EC4\u4EF6\uFF0C\u652F\u6301\u7ED1\u5236\u70B9\u3001\u7EBF\u3001\u9762\u3001\u5706\u7B49\u51E0\u4F55\u56FE\u5F62\u3002"}),`
`,o.exports.jsx(e.pre,{children:o.exports.jsx(e.code,{className:"language-js",children:`import { VMap, VTile, VDraw } from "v-ol-map";
`})}),`
`,o.exports.jsx(e.h2,{id:"\u57FA\u7840\u793A\u4F8B",children:"\u57FA\u7840\u793A\u4F8B"}),`
`,o.exports.jsxs(e.blockquote,{children:[`
`,o.exports.jsx(e.p,{children:"\u652F\u6301\u591A\u79CD\u7ED1\u5236\u7C7B\u578B\uFF0C\u7ED1\u5236\u5B8C\u6210\u540E\u81EA\u52A8\u6DFB\u52A0\u5230\u77E2\u91CF\u56FE\u5C42"}),`
`]}),`
`,o.exports.jsx(p,{of:a}),`
`,o.exports.jsx(e.h2,{id:"docs",children:"Docs"}),`
`,o.exports.jsx(i,{})]})}function g(s={}){const{wrapper:e}=Object.assign({},t(),s.components);return e?o.exports.jsx(e,Object.assign({},s,{children:o.exports.jsx(r,s)})):r(s)}export{g as default};
