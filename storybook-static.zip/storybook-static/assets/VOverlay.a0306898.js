import{j as e}from"./jsx-runtime.d19f6329.js";import{M as r,C as p,b as i}from"./index.6b7544c1.js";import{V as a,P as x}from"./VOverlay.stories.1e70f1ab.js";import{u as t}from"./index.912ed65d.js";import"./iframe.9b02d578.js";import"../sb-preview/runtime.js";import"./_commonjsHelpers.712cc82f.js";import"./index.d0b9ec93.js";import"./index.6eeffd5a.js";import"./index.7e22da21.js";import"./index.76fcd3ae.js";function s(o){const n=Object.assign({h1:"h1",p:"p",h2:"h2",pre:"pre",code:"code"},t(),o.components);return e.exports.jsxs(e.exports.Fragment,{children:[e.exports.jsx(r,{of:a}),`
`,e.exports.jsx(n.h1,{id:"voverlay-\u8986\u76D6\u7269\u7EC4\u4EF6",children:"VOverlay \u8986\u76D6\u7269\u7EC4\u4EF6"}),`
`,e.exports.jsx(n.p,{children:"\u7528\u4E8E\u5728\u5730\u56FE\u4E0A\u6307\u5B9A\u4F4D\u7F6E\u663E\u793A HTML \u5185\u5BB9\u7684\u8986\u76D6\u7269\u7EC4\u4EF6\uFF0C\u9002\u7528\u4E8E\u5F39\u7A97\u3001\u63D0\u793A\u6846\u3001\u6807\u6CE8\u7B49\u573A\u666F\u3002"}),`
`,e.exports.jsx(n.h2,{id:"\u57FA\u7840\u7528\u6CD5",children:"\u57FA\u7840\u7528\u6CD5"}),`
`,e.exports.jsx(n.pre,{children:e.exports.jsx(n.code,{className:"language-vue",children:`<template>
  <v-map :view="viewOptions">
    <v-overlay :position="[118.08, 24.47]" positioning="bottom-center" :offset="[0, -10]">
      <div class="popup">
        <h3>\u6807\u9898</h3>
        <p>\u5185\u5BB9</p>
      </div>
    </v-overlay>
  </v-map>
</template>
`})}),`
`,e.exports.jsx(n.h2,{id:"\u52A8\u6001\u663E\u793A\u9690\u85CF",children:"\u52A8\u6001\u663E\u793A/\u9690\u85CF"}),`
`,e.exports.jsxs(n.p,{children:["\u901A\u8FC7\u8BBE\u7F6E ",e.exports.jsx(n.code,{children:"position"})," \u4E3A ",e.exports.jsx(n.code,{children:"undefined"})," \u6765\u9690\u85CF\u8986\u76D6\u7269\uFF1A"]}),`
`,e.exports.jsx(n.pre,{children:e.exports.jsx(n.code,{className:"language-vue",children:`<template>
  <v-map :view="viewOptions">
    <v-overlay :position="showPopup ? coords : undefined">
      <div>\u70B9\u51FB\u663E\u793A\u7684\u5185\u5BB9</div>
    </v-overlay>
  </v-map>
</template>

<script>
export default {
  data() {
    return {
      showPopup: false,
      coords: [118.08, 24.47],
    };
  },
};
<\/script>
`})}),`
`,e.exports.jsx(n.h2,{id:"\u5F39\u7A97\u793A\u4F8B",children:"\u5F39\u7A97\u793A\u4F8B"}),`
`,e.exports.jsx(p,{of:x}),`
`,e.exports.jsx(n.h2,{id:"docs",children:"Docs"}),`
`,e.exports.jsx(i,{})]})}function w(o={}){const{wrapper:n}=Object.assign({},t(),o.components);return n?e.exports.jsx(n,Object.assign({},o,{children:e.exports.jsx(s,o)})):s(o)}export{w as default};
