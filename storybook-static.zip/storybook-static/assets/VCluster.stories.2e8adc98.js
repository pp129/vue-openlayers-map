import{n as p,V as f,a as m,b as d}from"./index.76fcd3ae.js";var g=function(){var n=this,t=n.$createElement,e=n._self._c||t;return e("div",{staticClass:"cluster-example"},[e("v-map",{staticStyle:{width:"100%",height:"600px"},attrs:{view:n.view}},[e("v-tile",{attrs:{"tile-type":"TD"}}),e("v-super-cluster",{attrs:{features:n.features,distance:60,"min-distance":40,cluster:{style:n.clusterStyle}}})],1),n._m(0)],1)},x=[function(){var n=this,t=n.$createElement,e=n._self._c||t;return e("div",{staticClass:"legend"},[e("div",{staticClass:"legend-item"},[e("div",{staticClass:"legend-color",staticStyle:{"background-color":"rgba(52, 211, 153, 0.8)"}}),e("span",{staticClass:"legend-text"},[n._v("1-10")])]),e("div",{staticClass:"legend-item"},[e("div",{staticClass:"legend-color",staticStyle:{"background-color":"rgba(59, 130, 246, 0.8)"}}),e("span",{staticClass:"legend-text"},[n._v("10-50")])]),e("div",{staticClass:"legend-item"},[e("div",{staticClass:"legend-color",staticStyle:{"background-color":"rgba(239, 68, 68, 0.8)"}}),e("span",{staticClass:"legend-text"},[n._v("50+")])])])}];const v={name:"ClusterExample",components:{VMap:f,VTile:m,VSuperCluster:d},data(){return{view:{center:[118.0894,24.4798],zoom:11,projection:"EPSG:4326"},features:this.generatePoints(100),clusterStyle:[{min:0,max:10,circle:{radius:15,fill:{color:"rgba(52, 211, 153, 0.8)"},stroke:{color:"#fff",width:2}},text:{fill:{color:"#fff"},font:"bold 14px sans-serif"}},{min:10,max:50,circle:{radius:20,fill:{color:"rgba(59, 130, 246, 0.8)"},stroke:{color:"#fff",width:2}},text:{fill:{color:"#fff"},font:"bold 16px sans-serif"}},{min:50,max:99999,circle:{radius:25,fill:{color:"rgba(239, 68, 68, 0.8)"},stroke:{color:"#fff",width:2}},text:{fill:{color:"#fff"},font:"bold 18px sans-serif"}}]}},methods:{generatePoints(n){const t=[];for(let e=0;e<n;e++)t.push({type:"point",coordinates:[118.0894+(Math.random()-.5)*.3,24.4798+(Math.random()-.5)*.3],id:`point-${e}`,properties:{name:`\u70B9 ${e+1}`},style:{circle:{radius:5,fill:{color:"rgba(255, 255, 0, 0.8)"},stroke:{color:"#fff",width:2}}}});return t}}},l={};var u=p(v,g,x,!1,_,"fcb29610",null,null);function _(n){for(let t in l)this[t]=l[t]}const h=function(){return u.exports}();u.exports.__docgenInfo={displayName:"ClusterExample",exportName:"default",description:"",tags:{},sourceFiles:["/Users/feipan/Desktop/\u9879\u76EE/\u6D4B\u8BD5/vue-openlayers-map-vite/src/stories/Cluster/ClusterExample.vue"]};const y=`<template>
  <div class="cluster-example">
    <v-map :view="view" style="width: 100%; height: 600px">
      <v-tile tile-type="TD" />
      <v-super-cluster :features="features" :distance="60" :min-distance="40" :cluster="{ style: clusterStyle }" />
    </v-map>
    <div class="legend">
      <div class="legend-item">
        <div class="legend-color" style="background-color: rgba(52, 211, 153, 0.8)"></div>
        <span class="legend-text">1-10</span>
      </div>
      <div class="legend-item">
        <div class="legend-color" style="background-color: rgba(59, 130, 246, 0.8)"></div>
        <span class="legend-text">10-50</span>
      </div>
      <div class="legend-item">
        <div class="legend-color" style="background-color: rgba(239, 68, 68, 0.8)"></div>
        <span class="legend-text">50+</span>
      </div>
    </div>
  </div>
</template>

<script>
import { VMap, VTile, VSuperCluster } from "@/packages";

export default {
  name: "ClusterExample",
  components: { VMap, VTile, VSuperCluster },
  data() {
    return {
      view: {
        center: [118.0894, 24.4798],
        zoom: 11,
        projection: "EPSG:4326",
      },
      features: this.generatePoints(100),
      clusterStyle: [
        {
          min: 0,
          max: 10,
          circle: {
            radius: 15,
            fill: { color: "rgba(52, 211, 153, 0.8)" },
            stroke: { color: "#fff", width: 2 },
          },
          text: { fill: { color: "#fff" }, font: "bold 14px sans-serif" },
        },
        {
          min: 10,
          max: 50,
          circle: {
            radius: 20,
            fill: { color: "rgba(59, 130, 246, 0.8)" },
            stroke: { color: "#fff", width: 2 },
          },
          text: { fill: { color: "#fff" }, font: "bold 16px sans-serif" },
        },
        {
          min: 50,
          max: 99999,
          circle: {
            radius: 25,
            fill: { color: "rgba(239, 68, 68, 0.8)" },
            stroke: { color: "#fff", width: 2 },
          },
          text: { fill: { color: "#fff" }, font: "bold 18px sans-serif" },
        },
      ],
    };
  },
  methods: {
    generatePoints(count) {
      const points = [];
      for (let i = 0; i < count; i++) {
        points.push({
          type: "point",
          coordinates: [118.0894 + (Math.random() - 0.5) * 0.3, 24.4798 + (Math.random() - 0.5) * 0.3],
          id: \`point-\${i}\`,
          properties: { name: \`\u70B9 \${i + 1}\` },
          style: {
            circle: {
              radius: 5,
              // \u9EC4\u8272\u5706\u70B9
              fill: { color: "rgba(255, 255, 0, 0.8)" },
              stroke: { color: "#fff", width: 2 },
            },
          },
        });
      }
      return points;
    },
  },
};
<\/script>

<style scoped>
.legend {
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  padding: 10px;
  position: absolute;
  right: 10px;
  bottom: 10px;
}
.legend-item {
  display: flex;
  align-items: center;
  margin-bottom: 5px;
}
.legend-color {
  width: 20px;
  height: 20px;
  margin-right: 5px;
}
.legend-text {
  font-size: 14px;
}
.cluster-example {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  position: relative;
  width: 100%;
  height: 100%;
}
.cluster-example .legend {
  margin-top: 20px;
}
.cluster-example .legend .legend-item {
  margin-bottom: 10px;
}
</style>
`,b={id:"2-6",title:"\u56FE\u5C42/Cluster\u805A\u5408\u56FE\u5C42",component:d},s={parameters:{docs:{description:{story:"\u805A\u5408\u56FE\u5C42\u793A\u4F8B\u3002\u6839\u636E\u805A\u5408\u6570\u91CF\u663E\u793A\u4E0D\u540C\u989C\u8272\uFF1A\u7EFF\u8272(<10)\u3001\u84DD\u8272(10-50)\u3001\u7EA2\u8272(>50)"},source:{language:"html",code:y}}},render:()=>({components:{ClusterExample:h},template:"<ClusterExample />"})};var r,o,a,i,c;s.parameters={...s.parameters,docs:{...(r=s.parameters)==null?void 0:r.docs,source:{originalSource:`{
  parameters: {
    docs: {
      description: {
        story: "\u805A\u5408\u56FE\u5C42\u793A\u4F8B\u3002\u6839\u636E\u805A\u5408\u6570\u91CF\u663E\u793A\u4E0D\u540C\u989C\u8272\uFF1A\u7EFF\u8272(<10)\u3001\u84DD\u8272(10-50)\u3001\u7EA2\u8272(>50)"
      },
      source: {
        language: "html",
        code: ClusterExampleRaw
      }
    }
  },
  render: () => ({
    components: {
      ClusterExample
    },
    template: "<ClusterExample />"
  })
}`,...(a=(o=s.parameters)==null?void 0:o.docs)==null?void 0:a.source},description:{story:"\u805A\u5408\u56FE\u5C42\u57FA\u7840\u793A\u4F8B",...(c=(i=s.parameters)==null?void 0:i.docs)==null?void 0:c.description}}};const C=["Default"],w=Object.freeze(Object.defineProperty({__proto__:null,default:b,Default:s,__namedExportsOrder:C},Symbol.toStringTag,{value:"Module"}));export{s as D,w as V};
