import{j as n}from"./jsx-runtime.d19f6329.js";import{M as r,C as a,b as p}from"./index.6b7544c1.js";import{V as i,D as h}from"./VPath.stories.23eae790.js";import{u as o}from"./index.912ed65d.js";import"./iframe.9b02d578.js";import"../sb-preview/runtime.js";import"./_commonjsHelpers.712cc82f.js";import"./index.d0b9ec93.js";import"./index.6eeffd5a.js";import"./index.7e22da21.js";import"./index.76fcd3ae.js";function s(t){const e=Object.assign({h1:"h1",p:"p",h2:"h2",pre:"pre",code:"code"},o(),t.components);return n.exports.jsxs(n.exports.Fragment,{children:[n.exports.jsx(r,{of:i}),`
`,n.exports.jsx(e.h1,{id:"vpath-\u8F68\u8FF9\u56DE\u653E\u7EC4\u4EF6",children:"VPath \u8F68\u8FF9\u56DE\u653E\u7EC4\u4EF6"}),`
`,n.exports.jsx(e.p,{children:"\u57FA\u4E8E OpenLayers \u5B9E\u73B0\u7684\u8F68\u8FF9\u8DEF\u5F84\u56DE\u653E\u7EC4\u4EF6\uFF0C\u652F\u6301\u5927\u91CF\u8F68\u8FF9\u70B9\u7684\u9AD8\u6548\u6E32\u67D3\u548C\u52A8\u753B\u64AD\u653E\u3002"}),`
`,n.exports.jsx(e.h2,{id:"\u57FA\u7840\u7528\u6CD5",children:"\u57FA\u7840\u7528\u6CD5"}),`
`,n.exports.jsx(e.pre,{children:n.exports.jsx(e.code,{className:"language-vue",children:`<template>
  <v-map :view="viewOptions">
    <v-tile tile-type="TD" />
    <v-path ref="pathRef" :path="pathData" :options="pathOptions" @load="onLoad" @bindMove="onMove" @bindEnd="onEnd" />
  </v-map>
</template>

<script>
export default {
  data() {
    return {
      pathData: [
        { longitude: 118.08, latitude: 24.47, gnssTime: 1640000000000 },
        { longitude: 118.09, latitude: 24.48, gnssTime: 1640000005000 },
        // ... \u66F4\u591A\u8F68\u8FF9\u70B9
      ],
      pathOptions: {
        lineColor: "rgba(24, 144, 255, 0.8)",
        lineWidth: 6,
        passlineColor: "#52c41a",
        passlineWidth: 4,
      },
    };
  },
  methods: {
    onLoad(pathObj) {
      // \u5F00\u59CB\u64AD\u653E
      this.$refs.pathRef.start();
    },
    onMove(e) {
      console.log("\u5F53\u524D\u4F4D\u7F6E\u7D22\u5F15:", e.currentIndex);
    },
    onEnd() {
      console.log("\u64AD\u653E\u7ED3\u675F");
    },
  },
};
<\/script>
`})}),`
`,n.exports.jsx(e.h2,{id:"\u64AD\u653E\u63A7\u5236",children:"\u64AD\u653E\u63A7\u5236"}),`
`,n.exports.jsx(e.pre,{children:n.exports.jsx(e.code,{className:"language-javascript",children:`// \u5F00\u59CB\u64AD\u653E
this.$refs.pathRef.start();

// \u4ECE\u6307\u5B9A\u4F4D\u7F6E\u5F00\u59CB
this.$refs.pathRef.start(100);

// \u6682\u505C
this.$refs.pathRef.pause();

// \u7EE7\u7EED
this.$refs.pathRef.resume();

// \u505C\u6B62
this.$refs.pathRef.stop();

// \u8BBE\u7F6E\u500D\u901F (1/2/4/8/16)
this.$refs.pathRef.setSpeedUp(4);
`})}),`
`,n.exports.jsx(e.h2,{id:"\u8F68\u8FF9\u56DE\u653E\u793A\u4F8B",children:"\u8F68\u8FF9\u56DE\u653E\u793A\u4F8B"}),`
`,n.exports.jsx(a,{of:h}),`
`,n.exports.jsx(e.h2,{id:"docs",children:"Docs"}),`
`,n.exports.jsx(p,{})]})}function M(t={}){const{wrapper:e}=Object.assign({},o(),t.components);return e?n.exports.jsx(e,Object.assign({},t,{children:n.exports.jsx(s,t)})):s(t)}export{M as default};
