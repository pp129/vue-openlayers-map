import{B as o}from"./basedecoder.801555b2.js";class d extends o{decodeBlock(e){return e}}export{d as default};
