import{n as W,V as f,a as E,c as F,f as m}from"./index.76fcd3ae.js";var V=function(){var e=this,s=e.$createElement,n=e._self._c||s;return n("div",{staticClass:"container"},[n("v-map",{attrs:{view:e.view}},[n("v-tile",{attrs:{"tile-type":"GD"}}),n("v-group-layer",{attrs:{visible:e.groupOptions.visible,opacity:e.groupOptions.opacity}},e._l(e.vectorLayers,function(t){return n("v-vector",{key:t.id,attrs:{"layer-id":t.id,features:t.features,visible:t.visible,opacity:t.opacity}})}),1),n("v-vector",{attrs:{"layer-id":e.layerOptions.id,features:e.layerOptions.features,visible:e.layerOptions.visible,opacity:e.layerOptions.opacity}})],1),n("div",{attrs:{id:"layertree"}},[n("ul",[n("li",{staticClass:"layertreenode"},[n("span",[e._v("\u56FE\u5C42\u7EC4")]),n("fieldset",[n("label",{staticClass:"checkbox",attrs:{for:"visible1"}},[e._v(" visible "),n("input",{directives:[{name:"model",rawName:"v-model",value:e.groupOptions.visible,expression:"groupOptions.visible"}],staticClass:"visible",attrs:{id:"visible1",type:"checkbox"},domProps:{checked:Array.isArray(e.groupOptions.visible)?e._i(e.groupOptions.visible,null)>-1:e.groupOptions.visible},on:{change:function(t){var i=e.groupOptions.visible,a=t.target,r=!!a.checked;if(Array.isArray(i)){var l=null,A=e._i(i,l);a.checked?A<0&&e.$set(e.groupOptions,"visible",i.concat([l])):A>-1&&e.$set(e.groupOptions,"visible",i.slice(0,A).concat(i.slice(A+1)))}else e.$set(e.groupOptions,"visible",r)}}})]),n("label",[e._v(" opacity "),n("input",{staticClass:"opacity",attrs:{type:"range",min:"0",max:"1",step:"0.01"},on:{input:function(t){return e.handleOpacity(t,e.groupOptions)}}})])]),n("ul",e._l(e.vectorLayers,function(t){return n("li",{key:t.id},[n("span",[e._v("layer "+e._s(t.name))]),n("fieldset",[n("label",{staticClass:"checkbox",attrs:{for:"visible10"}},[e._v(" visible "),n("input",{directives:[{name:"model",rawName:"v-model",value:t.visible,expression:"layer.visible"}],staticClass:"visible",attrs:{type:"checkbox"},domProps:{checked:Array.isArray(t.visible)?e._i(t.visible,null)>-1:t.visible},on:{change:function(i){var a=t.visible,r=i.target,l=!!r.checked;if(Array.isArray(a)){var A=null,p=e._i(a,A);r.checked?p<0&&e.$set(t,"visible",a.concat([A])):p>-1&&e.$set(t,"visible",a.slice(0,p).concat(a.slice(p+1)))}else e.$set(t,"visible",l)}}})]),n("label",[e._v(" opacity "),n("input",{staticClass:"opacity",attrs:{type:"range",min:"0",max:"1",step:"0.01"},on:{input:function(i){return e.handleOpacity(i,t)}}})])])])}),0)]),n("li",[n("span",[e._v("\u9EC4\u8272\u8981\u7D20\u56FE\u5C42")]),n("fieldset",[n("label",{staticClass:"checkbox",attrs:{for:"visible0"}},[e._v(" visible "),n("input",{directives:[{name:"model",rawName:"v-model",value:e.layerOptions.visible,expression:"layerOptions.visible"}],staticClass:"visible",attrs:{type:"checkbox"},domProps:{checked:Array.isArray(e.layerOptions.visible)?e._i(e.layerOptions.visible,null)>-1:e.layerOptions.visible},on:{change:function(t){var i=e.layerOptions.visible,a=t.target,r=!!a.checked;if(Array.isArray(i)){var l=null,A=e._i(i,l);a.checked?A<0&&e.$set(e.layerOptions,"visible",i.concat([l])):A>-1&&e.$set(e.layerOptions,"visible",i.slice(0,A).concat(i.slice(A+1)))}else e.$set(e.layerOptions,"visible",r)}}})]),n("label",[e._v(" opacity "),n("input",{staticClass:"opacity",attrs:{type:"range",min:"0",max:"1",step:"0.01"},on:{input:function(t){return e.handleOpacity(t,e.layerOptions)}}})])])])])])],1)},R=[];const C={name:"GroupLayer",components:{VMap:f,VTile:E,VVector:F,VGroupLayer:m},data(){return{view:{city:"\u53A6\u95E8",zoom:12},groupOptions:{id:"v_g",visible:!0,opacity:1},layerOptions:{id:"v_4",visible:!0,opacity:1,features:[{id:"point2",coordinates:[118.168742,24.487505],style:{zIndex:1,icon:{scale:.6,src:new URL("data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACIAAAAvCAYAAACG2RgcAAAABGdBTUEAALGPC/xhBQAAACBjSFJNAAB6JgAAgIQAAPoAAACA6AAAdTAAAOpgAAA6mAAAF3CculE8AAAABmJLR0QA/wD/AP+gvaeTAAAGvElEQVRYw7WXa4xdVRXHf2ufc+7c25nOTMdp0ZLWtpRO7cs2xRCqRqTalESM0gQlRRJj5IMxJBKBFKMxjTGB+CB8MCQqUqLRAqaaRsVSCNYKNbS2MBjoa4p2oEydTudxX+ees/fyw7l3emfmvqYtK9nJ3Dlr7f3b/7X2OvsIs7AzR2/u7gnsVsFsNqLrVGSZEZmrNsKpToAOOEe/4PaPjITPLf30sdFW55ZWnM4fvfH6tB/sMJ65EySdREo5XMBFgKKqgIIqIhRt7H4XKj9csOGfJ68I5N29G+fMWdy20/flXsQEICBespizqCuBRqiNQALEC0B8BFB1gAPVyDp9LH/WfW/hbUfyswY5f+Sm5ZmU7hFj1oBJFHAxaguo2im+aqOpk4qHeBkwPqgCDnXujaLVLy7Y+K9TLYOcf/WGDem07BPxekU8UC0DxDWhp4NcAvIRPw0YUItzbjhbcFuu3fTa0aYgZw+tv74r470sxusV8VGNUVtM0lHH6oEkCwh4acT4qItRZ4fHJ6JNiz715pS6MdU/XntqXXtnm+4RoRcxqEaoLTSEaGaKoraIuggRgwi9He2y569PXdNeD0QWr7I7jWE1kkiZKHE1TFEbJrUlBs+w+oa+eTurMzL5x8CLfX3ze1L9iB/gpdC4dSUapWZ6msTPoLYEGkfDY7p22S3HjwP4FZ/uucFDCoEYD2xI45pwRKNZ4lwRV4rR2GJSPn57mqB7DuKb2nEo2BIYD7Vx0NkuO4CvAmoA9u9a2RME3FHhnn48q81mC+T/O0Q0mkWjOOlrgCvFlC5myf9nmDhbP6XJyUuCUh5f2r/r2h5IakRWrTBbtdIxXX2Zba5I8X+jyQ8jk0OqBijh0Bg2G9bPUXkNFdKrlnbcCogBJOXJZxItTF011DpKI+NTFp0c3swRXphAraujikXK58QPdDMgPmA8T9YkWTGgtYNtrgCiiFejB7pafVGx2RC/K1NbFfFAHb5v1pL0YMQYltDEXCmuDQHgTN2Y+pYcBk9YUlFEjEinliWrG+ZixNReEE/rxjSYMBFGmFsBSd5LcomytpKNXtRSO7QeOKBMLQEfwKlOGJEPNFgJ09aOlgp1Htbeg6TSNDPnyF4CcZw1hoYgXnoucVznaGttEC/TAZQagyjnJvcSxdrfjNyk04gXIMbMHOIhZtrwA7x0W1NFotgdp9xZdSxnX2waYbME3R8E49UYZsYIuq9Bbb7ptIWiHqqAuF/9YfRPqow2ClB1ICFB90LE+IkKlVGtjucTzPsQSNjwFFam7T8Z7QW0cgNOnT2w6gddnd63m0WKPwcTzMMWJnClPGpLqLWI52NSc/AyHbhoFI2bqxGW3PMLbjrxeSCs1Hv8y6fP/1RVh5puIc7jiucwKUPQNZ9U7xLaehcRdM3HpAyuONQSBKBvD8YPA7aiCBVVXt+7ctuSRcGvafEzY3LGFu8j1ZYr6G8WfuL414GQqt6sQLzutrf+OJ6zP5/1rLM0a3n70ScuPABEkHS26tZngfBz2999sBC6F94vCFXGXz5W2P7IE8MXymsC4E33e2+06Kzv9n1yfccWY2RBa7O7ltxQouMD0V233H3mIEmnm2yDXg13d+hwIVy7Iv3C8g+33W6MzL1KIDp4PvrWhi+cfqYMMSWoXlEaILXvyes23vjRzJ9FpLPhCi0U6/Bo/P3rNp/6EUlxzngtNzodBmh79ffLP9u3LPMsQnC5IGMT7meLbz7xIFCkfFxrLVbPHFD62LZT+98Ziu5ruuU6ls+7Z9bffmJHWYmaEM1AKAeWPrL1rSfHs/bx2UJEkTt0z3fPfWNkhAJJOupeeJqBVGDCr90/+J1SpIdbhbCWc7ufu/iVvS9NjDeDgNqnppbp6cHQrlnRdnDF0ra7RGTq+33aqRGI/306vGPbN9/pJ2laTT8ZW1GE8kTx3fefPTU0bB9q5nxx3P3441+e7BUtne1WQShPGPVteXNXWNKX6jmVIn19+71DD88GYrYgFZjw8LH8A5JIPuP5yTPRfQf7x3JUte/3A0QBe+s9A2+MZd0vpj/MFfS3m+4ceIUWivNKQSqqRHv35x5RJVeFWHz+QHYns0zJlZoA6cG/r350/NhaHTuyUgf/1vc4kGaWd5krUSTZP8T7Dk48hlJCiQ4ezv6Ey0jJ5apQPQyQee+VNbuH/tH3LJAp/2+6X0vmt+BjgBQQlP0NSSMUwP/LgdHdJvka6KlSxJLUSUxyuprWTTNiKS8QTPOtvutWNlOdlur0aBlmhAZpa0W6RopUUkR5x5WPz6uuyOX6VltLxft/rDUTM9vzQdUAAAAldEVYdGRhdGU6Y3JlYXRlADIwMTktMDEtMDlUMDI6NTM6MTgrMDg6MDAeRleVAAAAJXRFWHRkYXRlOm1vZGlmeQAyMDE5LTAxLTA5VDAyOjUzOjE4KzA4OjAwbxvvKQAAAEN0RVh0c29mdHdhcmUAL3Vzci9sb2NhbC9pbWFnZW1hZ2ljay9zaGFyZS9kb2MvSW1hZ2VNYWdpY2stNy8vaW5kZXguaHRtbL21eQoAAAAYdEVYdFRodW1iOjpEb2N1bWVudDo6UGFnZXMAMaf/uy8AAAAXdEVYdFRodW1iOjpJbWFnZTo6SGVpZ2h0ADQ3F9+avAAAABZ0RVh0VGh1bWI6OkltYWdlOjpXaWR0aAAzNDk4nUwAAAAZdEVYdFRodW1iOjpNaW1ldHlwZQBpbWFnZS9wbmc/slZOAAAAF3RFWHRUaHVtYjo6TVRpbWUAMTU0Njk3MzU5OIJQq8AAAAARdEVYdFRodW1iOjpTaXplADQ2NjVCCrWUmwAAAGJ0RVh0VGh1bWI6OlVSSQBmaWxlOi8vL2hvbWUvd3d3cm9vdC9uZXdzaXRlL3d3dy5lYXN5aWNvbi5uZXQvY2RuLWltZy5lYXN5aWNvbi5jbi9maWxlcy8xMTIvMTEyOTg5OC5wbmfpoFlrAAAAAElFTkSuQmCC",self.location).href}},properties:{name:"feature2",level:2}}]},vectorLayers:[{id:"v_1",name:"\u84DD\u8272\u8981\u7D20\u56FE\u5C42",features:[{id:"point1",coordinates:[118.124742,24.487405],style:{zIndex:1,icon:{scale:.6,src:new URL("data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACIAAAAvCAYAAACG2RgcAAAABGdBTUEAALGPC/xhBQAAACBjSFJNAAB6JgAAgIQAAPoAAACA6AAAdTAAAOpgAAA6mAAAF3CculE8AAAABmJLR0QA/wD/AP+gvaeTAAAGp0lEQVRYw7WYbYhcVxnHf885d952N9nYXZK4ie22NQRMG2pp9ENUqFlqpVVaEEVCwEKgSaFiMagJohjC9kOEYj9oxZi0FJO2vgSKJm2sEtRKzFuDjdo0ZTebzb4n+9Ld2bkz955z/DB3dmc3c2dmN9s/HGa4c855fvM/z3POmREWoMcOda+wTc0Pi5ItImojcBciy4LQgXWTDrpw7l2Le8vPTbxx8ok7x+udW+rp9OhvhtdJMrFblP6mEtJIcaBEr0HocA4clL/61oavWGs6/7x15eVbAvnKL8822BV371VafVuEhIigpRgotI5CCKFxBIHD00LSA08Xp7QOrHVYR+CMeX402/2jc08+ML1gkC+9PPxJlUwcVUrdo6T47UMDucBhbNGBkoLAzRmrtZBJCgldAgJn3cXQDx4/uX3lB3WDdLzU92mdajyhlLRqVZwsV3CExlXqfhNISV4EJALGgrXuuslPP/S37Wvemd9XzX/whUO961yi4QRIqwgEBrJ+PEQ1hcYx5VsC41ACCK0kMic++0LvuqogG/e/2ah041GQVqUgMI5cwWLdwiFKcg78gotgBJBWL9lwdOP+NxvjQGR56/17UWqDVmCsIx/MzYVbgckHDmsdWoETtSHdfN9eylJj5s3mn3etV023vetpEilPyBVc3U7E5ch8iUBDSpEPHKEhCCfH7j37nbsuAXgzfdJNe8AlPCXkw+oQJnRMDBeYHg8o+BZbsCTSmswKj+WrUmivcjGWnPE0hMYlVKZxN/AE4ATgM51vtaTWPnANXDqTLLoRp+x4yEhPDmdn+5iCnf3WSmhpz9C4IhE7R1kMf/yD82vfe7bjhgIk0br+YXBpKFZJnKYnihClgJUawI0rOaYnwth5CrMx0ss+sf7LgChA0MkOAKUEYyu7YY1jtD+PaKmrjfX52JiSN8ahojJRytsCiAco0foeAC0Q2IpjyY6FOEDpm9ffxeREdixgWWuy4mdaCdY60N69gPIAEaXbqaGCb1ExAa1VFZ8HORs7X6kWotjiAYLIcpzDxI8jCB3KqxxQWRs7Jk4zKSCyrAQC0cZWrWSVJ7Gbm7KVnaq0jPMdwVkDpX3EmkFEraWKmho0OT/GMi+6G8xTJqOoKcfwDIgz4XviJauCNDdrCjGZ7GIcWd7sEdTiMMFlwCnA2jB/qhZ4plGTTCg8LTc1XaElE0KmSdc0xAb+qRKIy13vPVZrQLbgWNOWqBhUa9Bqtnka2tqSZPO1zyB/tO8Y0RYvQPrzL974L0q1VxvUmFKkFQwNB8U9IFL5oacUrFqZIGeF6bytNh3O2Sv/2t76KcBXFNPMhPmpV2q6krf4FtpvT9La4pFOK7QWPE/IZBQtLR533JGqCwLA+pOvAqa0NABm6v0zLwliag3O5i0DExadUqxeneTuO1O0t6dYtTqJTikGx21dEICZ6D73YgQycx8RILX5wMCrKpn+aj2zlKve+8gcikLu9TM713wDyJc74oAwP3LluQXPuEgF17ueA8Io9pxbvAJSmw8O/lF5qS9+lI7YIP/X0zs+/mjkhi0Fn/kcCKeHLj+LsAQ31RgJzh+63Bm5YWcfz5UC0p87MPCaJNOPfBSO2MD/0+kdbV8H/HKQ+YeBBYKprvM/hJq78yLk/In//XNPNPec0qp0KpkLnY9cMtOTv1pqjHB6/PlLP/va+xSXZY4qgVgg6Dvxwj5nTf+SUVh79dqxfT+lrFJqgQCYnj90jgZjAz9YKg5/tHfP4PFDHxJtYPNV7W8JDaQ3/7r/ZZXIPF4tSK1ktYXc0dM712wDcszLjVqOEA0o9P/l8DM4O7BYJ5yzAyN/P/IMUIiDqAXigLD78K7B3FDX04vaWwSXG+l+uvvwrkEqJGi9IDMwZ7+36XiYmzy4UI4wN3Xw37s3HScmQctV+woV/SVm+wf/8bFND20Rpdvmd6h0iXcmONd3YNe3JgcuZolJ0IU4UpLpP3fkw5HTv9vqsEM1yZ0dGj71+639547EVsliQRwQXvrFUz1T3e9so5h4cR0L2asXtnUffKqHOpZkoSAQVdGFH3e87Y/0PhlziTLB9as7Lu7teJsaVXIrICWY/JnvbvxtbuTqTuaeR4E/em3n+e/f9xplx3u9qusP3wp9PSB1/09OPthw+4b9QejI9vxn18V9D56MIMpLta6lqQdEAUkgEQEoitXmRc9LP/cLUQspJqiN3gfUsUy1QAS4LYKQCuMUs8try4KVu+AimNFq7tyKI1LWSgFLbckdWWzfctWVI/8HeDod76Lvx3wAAAAldEVYdGRhdGU6Y3JlYXRlADIwMTktMDEtMDlUMDI6NTM6MTArMDg6MDAtqRnyAAAAJXRFWHRkYXRlOm1vZGlmeQAyMDE5LTAxLTA5VDAyOjUzOjEwKzA4OjAwXPShTgAAAEN0RVh0c29mdHdhcmUAL3Vzci9sb2NhbC9pbWFnZW1hZ2ljay9zaGFyZS9kb2MvSW1hZ2VNYWdpY2stNy8vaW5kZXguaHRtbL21eQoAAAAYdEVYdFRodW1iOjpEb2N1bWVudDo6UGFnZXMAMaf/uy8AAAAXdEVYdFRodW1iOjpJbWFnZTo6SGVpZ2h0ADQ3F9+avAAAABZ0RVh0VGh1bWI6OkltYWdlOjpXaWR0aAAzNDk4nUwAAAAZdEVYdFRodW1iOjpNaW1ldHlwZQBpbWFnZS9wbmc/slZOAAAAF3RFWHRUaHVtYjo6TVRpbWUAMTU0Njk3MzU5MIyLI/IAAAARdEVYdFRodW1iOjpTaXplADQ1OThCpvICBQAAAGJ0RVh0VGh1bWI6OlVSSQBmaWxlOi8vL2hvbWUvd3d3cm9vdC9uZXdzaXRlL3d3dy5lYXN5aWNvbi5uZXQvY2RuLWltZy5lYXN5aWNvbi5jbi9maWxlcy8xMTIvMTEyOTc2OS5wbmfT3rLnAAAAAElFTkSuQmCC",self.location).href}},properties:{name:"feature1",level:2}}],visible:!0,opacity:1},{id:"v_2",name:"\u7EA2\u8272\u8981\u7D20\u56FE\u5C42",features:[{id:"point2",coordinates:[118.124342,24.417105],style:{zIndex:1,icon:{scale:.6,src:new URL("data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACIAAAAvCAYAAACG2RgcAAAABGdBTUEAALGPC/xhBQAAACBjSFJNAAB6JgAAgIQAAPoAAACA6AAAdTAAAOpgAAA6mAAAF3CculE8AAAABmJLR0QA/wD/AP+gvaeTAAAGn0lEQVRYw7WYX4zUVxXHP+f+fjM7s7vAQndTNNSsCMHIn0isfxO1FUrgoVjrgzGkiT4Y7UNNm/gghPhATH3QpKbxzVj1rdWEbcRQ0aaptiAUKCJYWFgRBHZYpOv+m/nN78+9x4ffzDID85uZXfAkJ/Obyb33fH7ne869NyMswE498cjAQI/dbjBbxOgmQVaDLHFxDOgsTi9ZOCPqXp/S8A+bX/3bVLdrSzeD/vnVT6/1vNxuz5ivI1IAEBGouYtiQEFTV1VQqs65l13C8x/5/bGL9wRy4vFP9A729OwzRr4rYnIYgxiTBrMWF0ZoEuOiGMnlMPkc4vsAqHPgHKoaO6cvTqr7wcMHTlYWDDK287Nrcr6OiDEbxBgQQZMEFwSotaC3x6bSNCzqeZhiEcn54BR1DufcWRfrV9Ycenesa5B/7Hh4c3/e/FE8M4jngSquEqA2aQLIAplf3PcxxWIqobU4524Fkdu2/vXTpzqCvPfYx9f29nhHxPcGxffTLFSr4JQsywJJIwimUGB+LWtvzbj4c5v/dK6pbkzjl0PbNvX1+DqCMCjGoFGMC4K2EB1NFRdU0ThGjEFgsN/JyKFND/ZlgchqtfsMrBdjasVYbSnFImhw1RB1FvEMBtYPL1++r1GR+Yfjj65b90Auf8b4fk568gvKRFtp7pSpt4iGES5O4v/GuvGTh0dHAfz6kAEvt0cgJ76HhmFbCGsd5ak5grkqSZRgrcXP+RT7CvQP9OJ5pvVEVbQaIb6HJEmuPye7gW8CKgD7P/XRBzYP+NdACqZYSIszgyOYC5iamEIbQBNrb7+0MSwfWkpvfyHzRUyxgAuqANXT5dlVT75z/X0DyLolZjukO6bGcSZEtVxlamKqFlDm3YggNUeVqZvTBOUwW8poXsrC2p7+HYAYQHwjW1PUtEhbTraOmVszGJG7XIxgGlyMMPP+LM66LG3BpPL5RrfUQYyHbAAQz7SVRFSbAtbdawGHKsFcdlbEeAB4YjYCxq/JOtypTZMowZjWJ4Ka1sUZR0mbFdOAIgwD4qfPshTIlAVA4wST0Q210/bu35NskHosgSV1EFRJ37VNyxoj2ZtbRqYkI1M1+vqnhdo+onBDYFWbPJLr7yMJgtYBMwD93gKdTJGb8yCJ0/N5I21B8gNLsFHrHdS0VoaeZf2QRG1BEuUioAZwodOjncjzvQW8fA7jm7tcfA/jNbuXz5Hv7emYkdDao3UQvV4ND3aaYMtl+h5amW7P3p1uEL/Z+1c9iJ2rdAS5GkUHqW3xAhTGtm18z4PhdpNMXy8UigSlm01bvE1uSybG0LtyCIIAV2kPkiiX1715/mNA1ZDKayuJfbkTvStXoBqwZPWHKAytwCsW0mPd9/GLBYqDK1g6vKorCIBy4l4BbF0aAHtyuvJrBNtpsitXiEo38H1D3weGWLp2mGUffoi+lUP4niEqTXQFAdjT09GvaiDz9xEBes5tXf9KwZid3azSBNftfaTBAqu/2/CX0a8BYWNGFEguV8MXFrziIu1qJXwBSGqxm66KbsfbY8dCdW/8vyEip2/sOHH5GDB/PDeBAMnl2fhH3KebaobpWCV+vpaNliAAdvvRC0cC5zruK4u1qnUHHz9+6a/Q3Bh3gjggPjVd3quw8ArslAqlemSysod07aZbU6vj0e46fnm0bN3P7zfIdGJf/NbZaxdIZWmyViAOiH8xPvFDq4zfLwjr+PfPxko/oaFTOoEA2J+euzVZisLv3y+QUpjs+eWNuRlovWlmgSiQfP7PF/YH1o3cK0TVupEvHh17lbQ2WnZkmysUDoj2j08+59DSYiGsUhr5z+xzQMQdBdotiALJ3nOlG1eC8BkWt7folSB6Zu+50g1aFGi3IPMwX3rr4mtz1r20UIq52L302LFLr5FRoI3mdfNWgF4Lq29vHVq2xRP54F0D3N0Zj1RP7h4rfePCbFSGzqd6p4zUzR4Yn505ODG5y6ETnQY7ZeJQaXbXgfHZzC5ZLIgCybN/H79ydjp8StPCyxoYnZkLn3p2dPwKXUiyUBCoddGXj108fC2Iv51xibLXwug7T57412E6dMm9gNRhwi+8df63Vyvx043nkVPi62H89CNHLv2G9LLTNQR0+Ydvi7E+0HPgM2seXbe08GONYkZn4u/tfPfSmzWIxlbtSppuQAyQB3I1AEPabX7t93xtXFTzhLRAXe05pguZOoEIsKIGIS3mGW7L6xqCNWZBazCT7bJzLxmRBq8HrPt9z8hixzZaVzXyP6BgM8Qy17HzAAAAJXRFWHRkYXRlOmNyZWF0ZQAyMDE5LTAxLTA5VDAyOjUzOjE1KzA4OjAwf5E2VQAAACV0RVh0ZGF0ZTptb2RpZnkAMjAxOS0wMS0wOVQwMjo1MzoxNSswODowMA7MjukAAABDdEVYdHNvZnR3YXJlAC91c3IvbG9jYWwvaW1hZ2VtYWdpY2svc2hhcmUvZG9jL0ltYWdlTWFnaWNrLTcvL2luZGV4Lmh0bWy9tXkKAAAAGHRFWHRUaHVtYjo6RG9jdW1lbnQ6OlBhZ2VzADGn/7svAAAAF3RFWHRUaHVtYjo6SW1hZ2U6OkhlaWdodAA0NxffmrwAAAAWdEVYdFRodW1iOjpJbWFnZTo6V2lkdGgAMzQ5OJ1MAAAAGXRFWHRUaHVtYjo6TWltZXR5cGUAaW1hZ2UvcG5nP7JWTgAAABd0RVh0VGh1bWI6Ok1UaW1lADE1NDY5NzM1OTX84dd9AAAAEXRFWHRUaHVtYjo6U2l6ZQA0NjE3Qj3M4JwAAABidEVYdFRodW1iOjpVUkkAZmlsZTovLy9ob21lL3d3d3Jvb3QvbmV3c2l0ZS93d3cuZWFzeWljb24ubmV0L2Nkbi1pbWcuZWFzeWljb24uY24vZmlsZXMvMTEyLzExMjk4NjUucG5n4GYvDwAAAABJRU5ErkJggg==",self.location).href}},properties:{name:"feature2",level:2}}],visible:!0,opacity:1},{id:"v_3",name:"\u7EFF\u8272\u8981\u7D20\u56FE\u5C42",features:[{id:"point3",coordinates:[118.124342,24.437105],style:{zIndex:1,icon:{scale:.6,src:new URL("data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACIAAAAvCAYAAACG2RgcAAAABGdBTUEAALGPC/xhBQAAACBjSFJNAAB6JgAAgIQAAPoAAACA6AAAdTAAAOpgAAA6mAAAF3CculE8AAAABmJLR0QA/wD/AP+gvaeTAAAGuklEQVRYw7WXbYxUZxXHf+d57szc3WXZLS7dWiCB1cYI1KiNHzR+w1RsrEm/aBpC0toYibYaTE0ErWmQ1LZCMESMUdNoYwxNFVo0UKtSRFvbJlibmlJoJct231mWYbe7c+fe58UPc3eZ2Z3ZO7usJzmZO3Ofl9/9n3OeOVdYhH30hQOdkm/bqpAtouQjCD0I7Ykx4P0kngse9wbe/0VdTp779107i82uLU0B/O1ntxDILq3U3YiEgiACggBCYhPA473HQ/rpI5w7bCL7yNnbv/n2dYHc9oeHW01n9x4V6G8IkhMRlCjAY5wlsQbjDMYkaBWQ1wFaaUBw3uFxeE/inD1YnBj//uCdD08vGmTTC4c+qHPqqCjZrEQhCMZZIlPGelsz1pik5rsWRSFXIFAB3vsKlHP/iSN713+3fuudpkE2/nn/xyQMn1dKdWlReDylZD5AI5BrQJowV0BEcM5hnR1zpej2d+7Y9VomSM/zj9+SD8OXtNJdgdIYZymbmEr061sjkMoGQiHIo5XGOluBmZr+1IU7H6rJG1X9pfvJB9t0LncUpEuJIrGGKAMiyzyeyJQx1lTyS+hyLYWj3U8+2NYIRNpu7t6Dkk1aKZx3lNNqWA4r2xjrHUo0IrIpvHHVnuqIzF5sePYHH1IdbW9o0blCkKOUlJtWYqHQzA1TmCsQmwTrbZKMT946+MW95wCCmTGqNdwN5AKlKZtkQQhnDKXLI5Qni9hyCRcn6EJIfmUnYVc3Ksg1DFNskkq+WJsL2lt3AfcCXgDW/OTr7ws3f6AfCMOgQGTKjSWeuMLkQC/euWtgSXztqZWmbc16Ch03NFyjEBQomzLgI/PWu2sH7j90WQFS6Fm7FQgBEmsWgCgyOdgLAqLVNVd61gGmBnqJJ4qNQ2lnQimhXtf9OUAUIAT6MwAK1fCscMYwNToASs93rUGrGp8e6ceZ+g9lvUMkTc+83gJIUNlfbwZQSuGqJK+2eOIKXkC0nndP6szx6Zxw1eq662lRGG9BqVsBFQAiWtaTYaZcQgVB3Xve14e35VLD9WZLQcn6GUUEYSWAdbbhROsMouuDSAMVrU0WWK+yl0D7DAikB9tCJVuBqH9fGiiilCbLPFiYOUccwyjWLjShJVxBFDf4F1f1lSoUWjJBxPvRWRBv7Vui9IIgbSs6SIpx/Zu6viKtKzqJWdi89W8DXgHOx8nLWeSFlnaCIIfSer6rAKV0jQdBnnxLe6YiPo5fngHx8fD48awJUybixq51aKXneWXzoMZXd61j2kSZIG6oeJz0iBcg7Pnr/jezyrglCGkRzdiV4ZqSNVVHvFKKVTe8nwhLKVkYxFvX2/fZXRuBqNKAgnXT5cNZ9CUTUfKWNd0b6FzZRSHfglIarXMUCq10dKzmppt6moIAcKXyU1Sqxs+ku43P9f46vO3D3xbxOgumbGPa8210tXUQqIDYJhhriEyZS1PjuAblXKOGx5be7P1VCjLbjwhQ2PDcY0+pMPeFzFXmWLP9SI0aUXzs3c8/9CWgTJqspOExydClA4tecYmWDF0+AJh075pW0fXfu+8VH5uT/28IHycnh7/y41eA2RjWgADG9I/+EGR5GtUGHLZv9JFUjbogALbvy/te8lGcea4smSJKjg/sOPhP0iRtBOKApHz24vfwLD4DMyl8FL3euxtIqtWoBwJgB3b+9JybKv1iuTnse6WDo9/95XkqYamxeiAOSCaPnd6LdYPLR+H6ir89uY+qSskCAbBjP//TeDI68Z1l4xi7uvu9p/8+wZzcyALxgOm7e88RX46PXi+Ei5Kj/dsefYZKbtStSLXQfCAeP/bqTu/80FIhvHNDkyf+tROImZOgzYJ4wBQPHRm2A5ceWOLZ4pPB8QeKh44MUydBmwWZhbm4/dETbqr0xGIp3FT0xNA9PzpBgwSttuzutrKAt4PFf7R+etMWUermeRvWe68x9kxx3zP3xL1DUzRI0MUoMmN28tSZiYlTr2/zzo9kS+FGpk++tm3y1JmGVbJUEA+Ysb2/uRidH9yO8417Yufj5Hz/9rHHn75IEyFZLAikVTS4Y/+L8Ujxq97LvCf1HpuMjO8YvP/Qi2RUyVxrJkfmKuMmfn/6fPsdn+jTbS1bEbRzDrxP3MjVrw1sf+wwlWanaYjFgsw02h7wV393+mzLJze+GnSu+Lg39nJ0Yfi+ofv2/TFVwlaNb3rxLFNAHshReSFT6QME6e/5dFycuklBXHqd0ESYskAEWJVCSJ15imt55qo2q05Qn8KMs0DiXo8iQq38vsqXXZGljq22psr3f7MZQ0UDx+1DAAAAJXRFWHRkYXRlOmNyZWF0ZQAyMDE5LTAxLTA5VDAyOjUzOjEzKzA4OjAwHEEDbwAAACV0RVh0ZGF0ZTptb2RpZnkAMjAxOS0wMS0wOVQwMjo1MzoxMyswODowMG0cu9MAAABDdEVYdHNvZnR3YXJlAC91c3IvbG9jYWwvaW1hZ2VtYWdpY2svc2hhcmUvZG9jL0ltYWdlTWFnaWNrLTcvL2luZGV4Lmh0bWy9tXkKAAAAGHRFWHRUaHVtYjo6RG9jdW1lbnQ6OlBhZ2VzADGn/7svAAAAF3RFWHRUaHVtYjo6SW1hZ2U6OkhlaWdodAA0NxffmrwAAAAWdEVYdFRodW1iOjpJbWFnZTo6V2lkdGgAMzQ5OJ1MAAAAGXRFWHRUaHVtYjo6TWltZXR5cGUAaW1hZ2UvcG5nP7JWTgAAABd0RVh0VGh1bWI6Ok1UaW1lADE1NDY5NzM1OTMVgnJIAAAAEXRFWHRUaHVtYjo6U2l6ZQA0NjM0QhVlZzEAAABidEVYdFRodW1iOjpVUkkAZmlsZTovLy9ob21lL3d3d3Jvb3QvbmV3c2l0ZS93d3cuZWFzeWljb24ubmV0L2Nkbi1pbWcuZWFzeWljb24uY24vZmlsZXMvMTEyLzExMjk4MDEucG5nw79q0gAAAABJRU5ErkJggg==",self.location).href}},properties:{name:"feature3",level:2}}],visible:!0,opacity:1}]}},methods:{handleOpacity(e,s){const t=e.target.valueAsNumber;s&&(s.opacity=t)}}},c={};var g=W(C,V,R,!1,O,"1a0e54d0",null,null);function O(e){for(let s in c)this[s]=c[s]}const L=function(){return g.exports}();g.exports.__docgenInfo={displayName:"GroupLayer",exportName:"default",description:"",tags:{},sourceFiles:["/Users/feipan/Desktop/\u9879\u76EE/\u6D4B\u8BD5/vue-openlayers-map-vite/src/stories/Group/index.vue"]};const x=`<template>
  <div class="container">
    <v-map :view="view">
      <v-tile tile-type="GD"></v-tile>
      <v-group-layer :visible="groupOptions.visible" :opacity="groupOptions.opacity">
        <v-vector
          v-for="layer in vectorLayers"
          :key="layer.id"
          :layer-id="layer.id"
          :features="layer.features"
          :visible="layer.visible"
          :opacity="layer.opacity"
        ></v-vector>
      </v-group-layer>
      <v-vector
        :layer-id="layerOptions.id"
        :features="layerOptions.features"
        :visible="layerOptions.visible"
        :opacity="layerOptions.opacity"
      ></v-vector>
    </v-map>
    <div id="layertree">
      <ul>
        <li class="layertreenode">
          <span>\u56FE\u5C42\u7EC4</span>
          <fieldset>
            <label class="checkbox" for="visible1">
              visible <input id="visible1" v-model="groupOptions.visible" class="visible" type="checkbox" />
            </label>
            <label>
              opacity
              <input
                class="opacity"
                type="range"
                min="0"
                max="1"
                step="0.01"
                @input="(evt) => handleOpacity(evt, groupOptions)"
              />
            </label>
          </fieldset>
          <ul>
            <li v-for="layer in vectorLayers" :key="layer.id">
              <span>layer {{ layer.name }}</span>
              <fieldset>
                <label class="checkbox" for="visible10">
                  visible <input v-model="layer.visible" class="visible" type="checkbox" />
                </label>
                <label>
                  opacity
                  <input class="opacity" type="range" min="0" max="1" step="0.01" @input="(evt) => handleOpacity(evt, layer)" />
                </label>
              </fieldset>
            </li>
          </ul>
        </li>
        <li>
          <span>\u9EC4\u8272\u8981\u7D20\u56FE\u5C42</span>
          <fieldset>
            <label class="checkbox" for="visible0">
              visible <input v-model="layerOptions.visible" class="visible" type="checkbox" />
            </label>
            <label>
              opacity
              <input
                class="opacity"
                type="range"
                min="0"
                max="1"
                step="0.01"
                @input="(evt) => handleOpacity(evt, layerOptions)"
              />
            </label>
          </fieldset>
        </li>
      </ul>
    </div>
  </div>
</template>

<script>
import { VMap, VVector, VTile, VGroupLayer } from "../../packages";
export default {
  name: "GroupLayer",
  components: {
    VMap,
    VTile,
    VVector,
    VGroupLayer,
  },
  data() {
    return {
      view: {
        city: "\u53A6\u95E8",
        zoom: 12,
      },
      groupOptions: {
        id: "v_g",
        visible: true,
        opacity: 1,
      },
      layerOptions: {
        id: "v_4",
        visible: true,
        opacity: 1,
        features: [
          {
            id: "point2",
            coordinates: [118.168742, 24.487505],
            style: {
              zIndex: 1,
              icon: {
                scale: 0.6,
                // src: require('@/assets/img/point_5.png')
                src: new URL("../../assets/img/point_4.png", import.meta.url).href,
              },
            },
            properties: {
              name: "feature2",
              level: 2,
            },
          },
        ],
      },
      vectorLayers: [
        {
          id: "v_1",
          name: "\u84DD\u8272\u8981\u7D20\u56FE\u5C42",
          features: [
            {
              id: "point1",
              coordinates: [118.124742, 24.487405],
              style: {
                zIndex: 1,
                icon: {
                  scale: 0.6,
                  src: new URL("../../assets/img/point_1.png", import.meta.url).href,
                },
              },
              properties: {
                name: "feature1",
                level: 2,
              },
            },
          ],
          visible: true,
          opacity: 1,
        },
        {
          id: "v_2",
          name: "\u7EA2\u8272\u8981\u7D20\u56FE\u5C42",
          features: [
            {
              id: "point2",
              coordinates: [118.124342, 24.417105],
              style: {
                zIndex: 1,
                icon: {
                  scale: 0.6,
                  src: new URL("../../assets/img/point_2.png", import.meta.url).href,
                },
              },
              properties: {
                name: "feature2",
                level: 2,
              },
            },
          ],
          visible: true,
          opacity: 1,
        },
        {
          id: "v_3",
          name: "\u7EFF\u8272\u8981\u7D20\u56FE\u5C42",
          features: [
            {
              id: "point3",
              coordinates: [118.124342, 24.437105],
              style: {
                zIndex: 1,
                icon: {
                  scale: 0.6,
                  src: new URL("../../assets/img/point_3.png", import.meta.url).href,
                },
              },
              properties: {
                name: "feature3",
                level: 2,
              },
            },
          ],
          visible: true,
          opacity: 1,
        },
      ],
    };
  },
  methods: {
    handleOpacity(evt, layer) {
      const target = evt.target;
      const value = target.valueAsNumber;
      if (layer) layer.opacity = value;
    },
  },
};
<\/script>

<style scoped>
.container {
  height: 100%;
  width: 100%;
  position: relative;
}
#layertree {
  z-index: 999;
  position: absolute;
  top: 10px;
  right: 10px;
  background: rgba(255, 255, 255, 0.8);
}
#layertree li > span {
  cursor: pointer;
}
#layertree label {
  display: block;
}
.layertreenode {
  padding-bottom: 24px;
  border-bottom: 1px solid #666;
}
</style>
`,Y={id:"2-1",title:"\u56FE\u5C42/GroupLayer\u56FE\u5C42\u7EC4",component:m,parameters:{docs:{description:{component:""}}}},o={parameters:{docs:{description:{story:"\u56FE\u5C42\u7EC4\u57FA\u7840\u793A\u4F8B\u3002\u5305\u542B\u4E00\u4E2A\u56FE\u5C42\u7EC4\uFF08\u84DD/\u7EA2/\u7EFF\u4E09\u4E2A\u56FE\u5C42\uFF09\u548C\u4E00\u4E2A\u72EC\u7ACB\u56FE\u5C42\uFF08\u9EC4\u8272\uFF09\uFF0C\u53EF\u901A\u8FC7\u53F3\u4E0A\u89D2\u63A7\u5236\u9762\u677F\u8C03\u6574"},source:{language:"html",code:x}}},render:()=>({components:{GroupLayerExample:L},template:"<GroupLayerExample />"})};var u,d,v,b,y;o.parameters={...o.parameters,docs:{...(u=o.parameters)==null?void 0:u.docs,source:{originalSource:`{
  parameters: {
    docs: {
      description: {
        story: "\u56FE\u5C42\u7EC4\u57FA\u7840\u793A\u4F8B\u3002\u5305\u542B\u4E00\u4E2A\u56FE\u5C42\u7EC4\uFF08\u84DD/\u7EA2/\u7EFF\u4E09\u4E2A\u56FE\u5C42\uFF09\u548C\u4E00\u4E2A\u72EC\u7ACB\u56FE\u5C42\uFF08\u9EC4\u8272\uFF09\uFF0C\u53EF\u901A\u8FC7\u53F3\u4E0A\u89D2\u63A7\u5236\u9762\u677F\u8C03\u6574"
      },
      source: {
        language: "html",
        code: GroupLayerExampleRaw
      }
    }
  },
  render: () => ({
    components: {
      GroupLayerExample
    },
    template: "<GroupLayerExample />"
  })
}`,...(v=(d=o.parameters)==null?void 0:d.docs)==null?void 0:v.source},description:{story:`\u56FE\u5C42\u7EC4\u57FA\u7840\u793A\u4F8B

\u5C55\u793A\u5982\u4F55\u4F7F\u7528 VGroupLayer \u7EC4\u4EF6\u7BA1\u7406\u591A\u4E2A\u77E2\u91CF\u56FE\u5C42\uFF0C
\u5E76\u901A\u8FC7\u63A7\u5236\u9762\u677F\u8C03\u6574\u53EF\u89C1\u6027\u548C\u900F\u660E\u5EA6`,...(y=(b=o.parameters)==null?void 0:b.docs)==null?void 0:y.description}}};const h=["Default"],Z=Object.freeze(Object.defineProperty({__proto__:null,default:Y,Default:o,__namedExportsOrder:h},Symbol.toStringTag,{value:"Module"}));export{o as D,Z as V};
