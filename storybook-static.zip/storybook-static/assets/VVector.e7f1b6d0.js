import{j as o}from"./jsx-runtime.d19f6329.js";import{M as p,C as r,b as x}from"./index.6b7544c1.js";import{V as i,D as c,M as a,G as d}from"./VVector.stories.450fe44a.js";import{u as n}from"./index.912ed65d.js";import"./iframe.9b02d578.js";import"../sb-preview/runtime.js";import"./_commonjsHelpers.712cc82f.js";import"./index.d0b9ec93.js";import"./index.6eeffd5a.js";import"./index.7e22da21.js";import"./index.76fcd3ae.js";import"./VMap.stories.ccd9cff5.js";function t(s){const e=Object.assign({h1:"h1",p:"p",pre:"pre",code:"code",h2:"h2",blockquote:"blockquote"},n(),s.components);return o.exports.jsxs(o.exports.Fragment,{children:[o.exports.jsx(p,{of:i}),`
`,o.exports.jsx(e.h1,{id:"v-vector",children:"v-vector"}),`
`,o.exports.jsx(e.p,{children:"\u77E2\u91CF\u56FE\u5C42\u7EC4\u4EF6\uFF0C\u652F\u6301\u70B9\u3001\u7EBF\u3001\u9762\u7B49\u591A\u79CD\u8981\u7D20\u7C7B\u578B\u3002"}),`
`,o.exports.jsx(e.pre,{children:o.exports.jsx(e.code,{className:"language-js",children:`import { VMap, VVector, VTile } from "v-ol-map";
`})}),`
`,o.exports.jsx(e.h2,{id:"\u9ED8\u8BA4\u793A\u4F8B",children:"\u9ED8\u8BA4\u793A\u4F8B"}),`
`,o.exports.jsxs(e.blockquote,{children:[`
`,o.exports.jsx(e.p,{children:"\u4F7F\u7528 features \u5C5E\u6027\u6DFB\u52A0\u77E2\u91CF\u8981\u7D20"}),`
`]}),`
`,o.exports.jsx(r,{of:c}),`
`,o.exports.jsx(e.h2,{id:"modify-\u7F16\u8F91\u6A21\u5F0F",children:"Modify \u7F16\u8F91\u6A21\u5F0F"}),`
`,o.exports.jsxs(e.blockquote,{children:[`
`,o.exports.jsx(e.p,{children:"\u8981\u7D20\u53EF\u7F16\u8F91\uFF0C\u542F\u7528\u540E\u53EF\u62D6\u62FD\u8981\u7D20\u79FB\u52A8\u4F4D\u7F6E"}),`
`]}),`
`,o.exports.jsx(r,{of:a}),`
`,o.exports.jsx(e.h2,{id:"geojson-\u57FA\u7840\u793A\u4F8B",children:"GeoJSON \u57FA\u7840\u793A\u4F8B"}),`
`,o.exports.jsxs(e.blockquote,{children:[`
`,o.exports.jsx(e.p,{children:"\u4F7F\u7528 GeoJSON \u6570\u636E\u751F\u6210\u8981\u7D20\uFF0C\u652F\u6301\u8981\u7D20\u7EA7\u522B\u6837\u5F0F\u548C\u56FE\u5C42\u7EDF\u4E00\u6837\u5F0F"}),`
`]}),`
`,o.exports.jsx(r,{of:d}),`
`,o.exports.jsx(e.h2,{id:"docs",children:"Docs"}),`
`,o.exports.jsx(x,{})]})}function D(s={}){const{wrapper:e}=Object.assign({},n(),s.components);return e?o.exports.jsx(e,Object.assign({},s,{children:o.exports.jsx(t,s)})):t(s)}export{D as default};
