import{j as e}from"./jsx-runtime.d19f6329.js";import{M as n,C as p,b as c}from"./index.6b7544c1.js";import{V as i,D as x}from"./VCluster.stories.2e8adc98.js";import{u as r}from"./index.912ed65d.js";import"./iframe.9b02d578.js";import"../sb-preview/runtime.js";import"./_commonjsHelpers.712cc82f.js";import"./index.d0b9ec93.js";import"./index.6eeffd5a.js";import"./index.7e22da21.js";import"./index.76fcd3ae.js";function t(o){const s=Object.assign({h1:"h1",p:"p",pre:"pre",code:"code",h2:"h2",blockquote:"blockquote"},r(),o.components);return e.exports.jsxs(e.exports.Fragment,{children:[e.exports.jsx(n,{of:i}),`
`,e.exports.jsx(s.h1,{id:"v-super-cluster",children:"v-super-cluster"}),`
`,e.exports.jsx(s.p,{children:"\u805A\u5408\u56FE\u5C42\u7EC4\u4EF6\uFF0C\u652F\u6301\u5927\u91CF\u70B9\u4F4D\u7684\u9AD8\u6548\u805A\u5408\u6E32\u67D3\u3002"}),`
`,e.exports.jsx(s.pre,{children:e.exports.jsx(s.code,{className:"language-js",children:`import { VMap, VTile, VSuperCluster } from "v-ol-map";
`})}),`
`,e.exports.jsx(s.h2,{id:"\u57FA\u7840\u793A\u4F8B",children:"\u57FA\u7840\u793A\u4F8B"}),`
`,e.exports.jsxs(s.blockquote,{children:[`
`,e.exports.jsx(s.p,{children:"\u6839\u636E\u805A\u5408\u6570\u91CF\u663E\u793A\u4E0D\u540C\u989C\u8272\u548C\u5927\u5C0F"}),`
`]}),`
`,e.exports.jsx(p,{of:x}),`
`,e.exports.jsx(s.h2,{id:"docs",children:"Docs"}),`
`,e.exports.jsx(c,{})]})}function g(o={}){const{wrapper:s}=Object.assign({},r(),o.components);return s?e.exports.jsx(s,Object.assign({},o,{children:e.exports.jsx(t,o)})):t(o)}export{g as default};
