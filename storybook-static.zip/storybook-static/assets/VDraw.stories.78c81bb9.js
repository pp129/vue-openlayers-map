import{n as w,V as m,a as y,c as D,d}from"./index.76fcd3ae.js";var v=function(){var e=this,t=e.$createElement,n=e._self._c||t;return n("div",{staticClass:"draw-example"},[n("v-map",{staticStyle:{width:"100%",height:"600px"},attrs:{view:e.view}},[n("v-tile",{attrs:{"tile-type":"TD"}}),n("v-vector",{attrs:{features:e.drawnFeatures}}),e.isDrawing?n("v-draw",{attrs:{type:e.drawType},on:{drawend:e.onDrawEnd}}):e._e()],1),n("div",{staticClass:"toolbar"},[e._l(e.tools,function(a){return n("button",{key:a.type,class:{active:e.drawType===a.type&&e.isDrawing},on:{click:function(T){return e.selectTool(a.type)}}},[e._v(" "+e._s(a.label)+" ")])}),n("button",{on:{click:e.stopDrawing}},[e._v("\u505C\u6B62")]),n("button",{on:{click:function(a){e.drawnFeatures=[]}}},[e._v("\u6E05\u9664")])],2)],1)},g=[];const f={name:"DrawExample",components:{VMap:m,VTile:y,VVector:D,VDraw:d},data(){return{view:{center:[118.0894,24.4798],zoom:13,projection:"EPSG:4326"},isDrawing:!1,drawType:"Point",drawnFeatures:[],tools:[{type:"Point",label:"\u70B9"},{type:"LineString",label:"\u7EBF"},{type:"Polygon",label:"\u9762"},{type:"Circle",label:"\u5706"}]}},methods:{selectTool(e){this.drawType=e,this.isDrawing=!0},stopDrawing(){this.isDrawing=!1},onDrawEnd(e){const t=e.getGeometry();this.drawnFeatures.push({type:this.drawType,coordinates:t.getCoordinates(),id:`drawn-${Date.now()}`,style:{fill:{color:"rgba(67, 126, 255, 0.3)"},stroke:{color:"#437eff",width:2}}})}}},o={};var u=w(f,v,g,!1,b,"135613fb",null,null);function b(e){for(let t in o)this[t]=o[t]}const _=function(){return u.exports}();u.exports.__docgenInfo={displayName:"DrawExample",exportName:"default",description:"",tags:{},sourceFiles:["/Users/feipan/Desktop/\u9879\u76EE/\u6D4B\u8BD5/vue-openlayers-map-vite/src/stories/Draw/DrawExample.vue"]};const x=`<template>
  <div class="draw-example">
    <v-map :view="view" style="width: 100%; height: 600px">
      <v-tile tile-type="TD" />
      <v-vector :features="drawnFeatures" />
      <v-draw v-if="isDrawing" :type="drawType" @drawend="onDrawEnd" />
    </v-map>
    <div class="toolbar">
      <button
        v-for="tool in tools"
        :key="tool.type"
        :class="{ active: drawType === tool.type && isDrawing }"
        @click="selectTool(tool.type)"
      >
        {{ tool.label }}
      </button>
      <button @click="stopDrawing">\u505C\u6B62</button>
      <button @click="drawnFeatures = []">\u6E05\u9664</button>
    </div>
  </div>
</template>

<script>
import { VMap, VTile, VVector, VDraw } from "v-ol-map";

export default {
  name: "DrawExample",
  components: { VMap, VTile, VVector, VDraw },
  data() {
    return {
      view: { center: [118.0894, 24.4798], zoom: 13, projection: "EPSG:4326" },
      isDrawing: false,
      drawType: "Point",
      drawnFeatures: [],
      tools: [
        { type: "Point", label: "\u70B9" },
        { type: "LineString", label: "\u7EBF" },
        { type: "Polygon", label: "\u9762" },
        { type: "Circle", label: "\u5706" },
      ],
    };
  },
  methods: {
    selectTool(type) {
      this.drawType = type;
      this.isDrawing = true;
    },
    stopDrawing() {
      this.isDrawing = false;
    },
    onDrawEnd(feature) {
      const geom = feature.getGeometry();
      this.drawnFeatures.push({
        type: this.drawType,
        coordinates: geom.getCoordinates(),
        id: \`drawn-\${Date.now()}\`,
        style: {
          fill: { color: "rgba(67, 126, 255, 0.3)" },
          stroke: { color: "#437eff", width: 2 },
        },
      });
    },
  },
};
<\/script>

<style scoped>
.draw-example {
  position: relative;
}
.toolbar {
  position: absolute;
  top: 10px;
  left: 10px;
  background: white;
  padding: 10px;
  border-radius: 4px;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.15);
}
.toolbar button {
  margin-right: 5px;
  padding: 6px 12px;
  border: 1px solid #ddd;
  border-radius: 4px;
  cursor: pointer;
}
.toolbar button.active {
  background: #1890ff;
  color: white;
  border-color: #1890ff;
}
</style>
`,h={id:"3-1",title:"\u5DE5\u5177/Draw\u7ED8\u5236\u5DE5\u5177",component:d,parameters:{docs:{description:{component:""}}}},r={parameters:{docs:{description:{story:"\u7ED1\u5236\u5DE5\u5177\u793A\u4F8B\u3002\u652F\u6301\u70B9\u3001\u7EBF\u3001\u9762\u3001\u5706\u7B49\u591A\u79CD\u7ED1\u5236\u7C7B\u578B"},source:{language:"html",code:x}}},render:()=>({components:{DrawExample:_},template:"<DrawExample />"})};var s,i,l,p,c;r.parameters={...r.parameters,docs:{...(s=r.parameters)==null?void 0:s.docs,source:{originalSource:`{
  parameters: {
    docs: {
      description: {
        story: "\u7ED1\u5236\u5DE5\u5177\u793A\u4F8B\u3002\u652F\u6301\u70B9\u3001\u7EBF\u3001\u9762\u3001\u5706\u7B49\u591A\u79CD\u7ED1\u5236\u7C7B\u578B"
      },
      source: {
        language: "html",
        code: DrawExampleRaw
      }
    }
  },
  render: () => ({
    components: {
      DrawExample
    },
    template: "<DrawExample />"
  })
}`,...(l=(i=r.parameters)==null?void 0:i.docs)==null?void 0:l.source},description:{story:"\u7ED1\u5236\u5DE5\u5177\u57FA\u7840\u793A\u4F8B",...(c=(p=r.parameters)==null?void 0:p.docs)==null?void 0:c.description}}};const E=["Default"],F=Object.freeze(Object.defineProperty({__proto__:null,default:h,Default:r,__namedExportsOrder:E},Symbol.toStringTag,{value:"Module"}));export{r as D,F as V};
