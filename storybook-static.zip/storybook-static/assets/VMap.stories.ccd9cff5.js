import{n as m,V as c,a as d}from"./index.76fcd3ae.js";var f=function(){var t=this,n=t.$createElement,a=t._self._c||n;return a("v-map",{staticStyle:{width:"100%",height:"600px"},attrs:{view:t.view}},[a("v-tile",{attrs:{"tile-type":"TD"}})],1)},v=[];const _={name:"MapDefaultExample",components:{VMap:c,VTile:d},data(){return{view:{center:[118.1689,24.6478],zoom:10}}}},r={};var i=m(_,f,v,!1,D,null,null,null);function D(t){for(let n in r)this[n]=r[n]}const E=function(){return i.exports}();i.exports.__docgenInfo={displayName:"MapDefaultExample",exportName:"default",description:"",tags:{},sourceFiles:["/Users/feipan/Desktop/\u9879\u76EE/\u6D4B\u8BD5/vue-openlayers-map-vite/src/stories/Map/MapDefaultExample.vue"]};const M=`<template>
  <v-map :view="view" style="width: 100%; height: 600px">
    <v-tile tile-type="TD" />
  </v-map>
</template>

<script>
import { VMap, VTile } from "@/packages";

export default {
  name: "MapDefaultExample",
  components: { VMap, VTile },
  data() {
    return {
      // \u5730\u56FE\u89C6\u56FE\u914D\u7F6E
      view: {
        center: [118.1689, 24.6478], // \u4E2D\u5FC3\u70B9\u5750\u6807 [\u7ECF\u5EA6, \u7EAC\u5EA6]
        zoom: 10, // \u7F29\u653E\u7EA7\u522B
      },
    };
  },
};
<\/script>
`,x={id:"1-1",title:"\u5730\u56FE/Map\u5730\u56FE\u5BB9\u5668",component:c,parameters:{docs:{description:{component:""}}}},e={args:{view:{center:[118.1689,24.6478],zoom:10}},parameters:{docs:{description:{story:"\u57FA\u7840\u5730\u56FE\u793A\u4F8B\uFF0C\u914D\u7F6E\u4E2D\u5FC3\u70B9\u548C\u7F29\u653E\u7EA7\u522B"},source:{language:"html",code:M}}},render:()=>({components:{MapDefaultExample:E},template:"<MapDefaultExample />"})};var o,s,p,u,l;e.parameters={...e.parameters,docs:{...(o=e.parameters)==null?void 0:o.docs,source:{originalSource:`{
  args: {
    view: {
      center: [118.1689, 24.6478],
      zoom: 10
    }
  },
  parameters: {
    docs: {
      description: {
        story: "\u57FA\u7840\u5730\u56FE\u793A\u4F8B\uFF0C\u914D\u7F6E\u4E2D\u5FC3\u70B9\u548C\u7F29\u653E\u7EA7\u522B"
      },
      source: {
        language: "html",
        code: MapDefaultExampleRaw
      }
    }
  },
  render: () => ({
    components: {
      MapDefaultExample
    },
    template: "<MapDefaultExample />"
  })
}`,...(p=(s=e.parameters)==null?void 0:s.docs)==null?void 0:p.source},description:{story:`\u9ED8\u8BA4\u793A\u4F8B

\u5C55\u793A\u57FA\u7840\u5730\u56FE\u914D\u7F6E`,...(l=(u=e.parameters)==null?void 0:u.docs)==null?void 0:l.description}}};const g=["Default"],w=Object.freeze(Object.defineProperty({__proto__:null,default:x,Default:e,__namedExportsOrder:g},Symbol.toStringTag,{value:"Module"}));export{e as D,w as V};
