import{j as o}from"./jsx-runtime.d19f6329.js";import{M as n,C as p,b as a}from"./index.6b7544c1.js";import{V as i,D as c}from"./VGraphic.stories.c8339b82.js";import{u as t}from"./index.912ed65d.js";import"./iframe.9b02d578.js";import"../sb-preview/runtime.js";import"./_commonjsHelpers.712cc82f.js";import"./index.d0b9ec93.js";import"./index.6eeffd5a.js";import"./index.7e22da21.js";import"./index.76fcd3ae.js";function r(e){const s=Object.assign({h1:"h1",p:"p",pre:"pre",code:"code",h2:"h2",blockquote:"blockquote"},t(),e.components);return o.exports.jsxs(o.exports.Fragment,{children:[o.exports.jsx(n,{of:i}),`
`,o.exports.jsx(s.h1,{id:"v-graphic",children:"v-graphic"}),`
`,o.exports.jsx(s.p,{children:"Canvas \u56FE\u5F62\u56FE\u5C42\uFF0C\u4F7F\u7528 Canvas 2D \u9AD8\u6548\u6E32\u67D3\u5927\u91CF\u56FE\u5F62\u3002"}),`
`,o.exports.jsx(s.pre,{children:o.exports.jsx(s.code,{className:"language-js",children:`import { VMap, VTile, VGraphic } from "v-ol-map";
`})}),`
`,o.exports.jsx(s.h2,{id:"\u57FA\u7840\u793A\u4F8B",children:"\u57FA\u7840\u793A\u4F8B"}),`
`,o.exports.jsxs(s.blockquote,{children:[`
`,o.exports.jsx(s.p,{children:"\u4F7F\u7528 Canvas \u6E32\u67D3\u5927\u91CF\u70B9\u4F4D\uFF0C\u6027\u80FD\u4F18\u4E8E\u77E2\u91CF\u56FE\u5C42"}),`
`]}),`
`,o.exports.jsx(p,{of:c}),`
`,o.exports.jsx(s.h2,{id:"docs",children:"Docs"}),`
`,o.exports.jsx(a,{})]})}function v(e={}){const{wrapper:s}=Object.assign({},t(),e.components);return s?o.exports.jsx(s,Object.assign({},e,{children:o.exports.jsx(r,e)})):r(e)}export{v as default};
