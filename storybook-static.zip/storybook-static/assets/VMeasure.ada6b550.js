import{j as e}from"./jsx-runtime.d19f6329.js";import{M as n,C as p,b as i}from"./index.6b7544c1.js";import{V as x,D as a}from"./VMeasure.stories.34dbf24f.js";import{u as t}from"./index.912ed65d.js";import"./iframe.9b02d578.js";import"../sb-preview/runtime.js";import"./_commonjsHelpers.712cc82f.js";import"./index.d0b9ec93.js";import"./index.6eeffd5a.js";import"./index.7e22da21.js";import"./index.76fcd3ae.js";function r(s){const o=Object.assign({h1:"h1",p:"p",pre:"pre",code:"code",h2:"h2",blockquote:"blockquote"},t(),s.components);return e.exports.jsxs(e.exports.Fragment,{children:[e.exports.jsx(n,{of:x}),`
`,e.exports.jsx(o.h1,{id:"v-measure",children:"v-measure"}),`
`,e.exports.jsx(o.p,{children:"\u6D4B\u91CF\u5DE5\u5177\u7EC4\u4EF6\uFF0C\u652F\u6301\u8DDD\u79BB\u6D4B\u91CF\u548C\u9762\u79EF\u6D4B\u91CF\u3002"}),`
`,e.exports.jsx(o.pre,{children:e.exports.jsx(o.code,{className:"language-js",children:`import { VMap, VTile, VMeasure } from "v-ol-map";
`})}),`
`,e.exports.jsx(o.h2,{id:"\u57FA\u7840\u793A\u4F8B",children:"\u57FA\u7840\u793A\u4F8B"}),`
`,e.exports.jsxs(o.blockquote,{children:[`
`,e.exports.jsx(o.p,{children:"\u6D4B\u8DDD\u548C\u6D4B\u9762\u5DE5\u5177"}),`
`]}),`
`,e.exports.jsx(p,{of:a}),`
`,e.exports.jsx(o.h2,{id:"docs",children:"Docs"}),`
`,e.exports.jsx(i,{})]})}function C(s={}){const{wrapper:o}=Object.assign({},t(),s.components);return o?e.exports.jsx(o,Object.assign({},s,{children:e.exports.jsx(r,s)})):r(s)}export{C as default};
