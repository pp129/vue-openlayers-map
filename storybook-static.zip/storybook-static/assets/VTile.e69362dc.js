import{j as e}from"./jsx-runtime.d19f6329.js";import{M as x,C as r,b as p}from"./index.6b7544c1.js";import{V as i,D as c,X as l,W as d}from"./VTile.stories.a8527e4b.js";import{u as n}from"./index.912ed65d.js";import"./iframe.9b02d578.js";import"../sb-preview/runtime.js";import"./_commonjsHelpers.712cc82f.js";import"./index.d0b9ec93.js";import"./index.6eeffd5a.js";import"./index.7e22da21.js";import"./index.76fcd3ae.js";import"./VMap.stories.ccd9cff5.js";function t(o){const s=Object.assign({h1:"h1",p:"p",pre:"pre",code:"code",h2:"h2",blockquote:"blockquote"},n(),o.components);return e.exports.jsxs(e.exports.Fragment,{children:[e.exports.jsx(x,{of:i}),`
`,e.exports.jsx(s.h1,{id:"v-tile",children:"v-tile"}),`
`,e.exports.jsx(s.p,{children:"\u74E6\u7247\u56FE\u5C42\u7EC4\u4EF6\uFF0C\u652F\u6301\u591A\u79CD\u74E6\u7247\u5730\u56FE\u670D\u52A1\u3002"}),`
`,e.exports.jsx(s.pre,{children:e.exports.jsx(s.code,{className:"language-js",children:`import { VMap, VTile } from "v-ol-map";
`})}),`
`,e.exports.jsx(s.h2,{id:"\u9ED8\u8BA4\u793A\u4F8B---\u5929\u5730\u56FE",children:"\u9ED8\u8BA4\u793A\u4F8B - \u5929\u5730\u56FE"}),`
`,e.exports.jsxs(s.blockquote,{children:[`
`,e.exports.jsx(s.p,{children:"\u4F7F\u7528\u5929\u5730\u56FE\u4F5C\u4E3A\u5E95\u56FE"}),`
`]}),`
`,e.exports.jsx(r,{of:c}),`
`,e.exports.jsx(s.h2,{id:"xyz-\u74E6\u7247",children:"XYZ \u74E6\u7247"}),`
`,e.exports.jsxs(s.blockquote,{children:[`
`,e.exports.jsx(s.p,{children:"\u4F7F\u7528\u81EA\u5B9A\u4E49 XYZ \u74E6\u7247\u670D\u52A1"}),`
`]}),`
`,e.exports.jsx(r,{of:l}),`
`,e.exports.jsx(s.h2,{id:"wms-\u56FE\u5C42",children:"WMS \u56FE\u5C42"}),`
`,e.exports.jsxs(s.blockquote,{children:[`
`,e.exports.jsxs(s.p,{children:["\u57FA\u4E8E",e.exports.jsx(s.code,{children:"ol/source/TileWMS"}),"\u7684 WMS \u56FE\u5C42"]}),`
`]}),`
`,e.exports.jsx(r,{of:d}),`
`,e.exports.jsx(s.h2,{id:"docs",children:"Docs"}),`
`,e.exports.jsx(p,{})]})}function k(o={}){const{wrapper:s}=Object.assign({},n(),o.components);return s?e.exports.jsx(s,Object.assign({},o,{children:e.exports.jsx(t,o)})):t(o)}export{k as default};
