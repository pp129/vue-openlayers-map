import{j as e}from"./jsx-runtime.d19f6329.js";import{M as n,C as p,b as a}from"./index.6b7544c1.js";import{V as i,D as x}from"./VHeatmap.stories.e08eeaa7.js";import{u as r}from"./index.912ed65d.js";import"./iframe.9b02d578.js";import"../sb-preview/runtime.js";import"./_commonjsHelpers.712cc82f.js";import"./index.d0b9ec93.js";import"./index.6eeffd5a.js";import"./index.7e22da21.js";import"./index.76fcd3ae.js";function s(t){const o=Object.assign({h1:"h1",p:"p",pre:"pre",code:"code",h2:"h2",blockquote:"blockquote"},r(),t.components);return e.exports.jsxs(e.exports.Fragment,{children:[e.exports.jsx(n,{of:i}),`
`,e.exports.jsx(o.h1,{id:"v-heatmap",children:"v-heatmap"}),`
`,e.exports.jsx(o.p,{children:"\u70ED\u529B\u56FE\u7EC4\u4EF6\uFF0C\u7528\u4E8E\u53EF\u89C6\u5316\u70B9\u6570\u636E\u7684\u5206\u5E03\u5BC6\u5EA6\u3002"}),`
`,e.exports.jsx(o.pre,{children:e.exports.jsx(o.code,{className:"language-js",children:`import { VMap, VTile, VHeatmap } from "v-ol-map";
`})}),`
`,e.exports.jsx(o.h2,{id:"\u57FA\u7840\u793A\u4F8B",children:"\u57FA\u7840\u793A\u4F8B"}),`
`,e.exports.jsxs(o.blockquote,{children:[`
`,e.exports.jsx(o.p,{children:"\u6839\u636E\u70B9\u4F4D\u6743\u91CD\u663E\u793A\u70ED\u529B\u5206\u5E03"}),`
`]}),`
`,e.exports.jsx(p,{of:x}),`
`,e.exports.jsx(o.h2,{id:"docs",children:"Docs"}),`
`,e.exports.jsx(a,{})]})}function C(t={}){const{wrapper:o}=Object.assign({},r(),t.components);return o?e.exports.jsx(o,Object.assign({},t,{children:e.exports.jsx(s,t)})):s(t)}export{C as default};
