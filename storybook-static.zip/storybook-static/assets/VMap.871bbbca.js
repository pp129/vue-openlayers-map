import{j as o}from"./jsx-runtime.d19f6329.js";import{M as n,C as p,b as i}from"./index.6b7544c1.js";import{V as x,D as a}from"./VMap.stories.ccd9cff5.js";import{u as r}from"./index.912ed65d.js";import"./iframe.9b02d578.js";import"../sb-preview/runtime.js";import"./_commonjsHelpers.712cc82f.js";import"./index.d0b9ec93.js";import"./index.6eeffd5a.js";import"./index.7e22da21.js";import"./index.76fcd3ae.js";function t(s){const e=Object.assign({h1:"h1",p:"p",pre:"pre",code:"code",h2:"h2",blockquote:"blockquote"},r(),s.components);return o.exports.jsxs(o.exports.Fragment,{children:[o.exports.jsx(n,{of:x}),`
`,o.exports.jsx(e.h1,{id:"v-map",children:"v-map"}),`
`,o.exports.jsx(e.p,{children:"\u5730\u56FE\u5BB9\u5668\u7EC4\u4EF6\uFF0C\u57FA\u4E8E OpenLayers \u5C01\u88C5\uFF0C\u652F\u6301\u591A\u79CD\u5750\u6807\u7CFB\u548C\u89C6\u56FE\u914D\u7F6E\u3002"}),`
`,o.exports.jsx(e.pre,{children:o.exports.jsx(e.code,{className:"language-js",children:`import { VMap, VTile } from "v-ol-map";
`})}),`
`,o.exports.jsx(e.h2,{id:"\u57FA\u7840\u793A\u4F8B",children:"\u57FA\u7840\u793A\u4F8B"}),`
`,o.exports.jsxs(e.blockquote,{children:[`
`,o.exports.jsx(e.p,{children:"\u914D\u7F6E\u4E2D\u5FC3\u70B9\u5750\u6807\u548C\u7F29\u653E\u7EA7\u522B"}),`
`]}),`
`,o.exports.jsx(p,{of:a}),`
`,o.exports.jsx(e.h2,{id:"docs",children:"Docs"}),`
`,o.exports.jsx(i,{})]})}function C(s={}){const{wrapper:e}=Object.assign({},r(),s.components);return e?o.exports.jsx(e,Object.assign({},s,{children:o.exports.jsx(t,s)})):t(s)}export{C as default};
