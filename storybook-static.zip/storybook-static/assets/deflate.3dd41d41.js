import{i as r}from"./pako.esm.ebcc5ed5.js";import{B as a}from"./basedecoder.801555b2.js";class s extends a{decodeBlock(e){return r(new Uint8Array(e)).buffer}}export{s as default};
